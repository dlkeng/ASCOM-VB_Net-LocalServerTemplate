Imports System
Imports System.Reflection
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.
<Assembly: AssemblyTitle("ASCOM $safeprojectname$ server")>
<Assembly: AssemblyDescription("ASCOM multi-interface server for $safeprojectname$")> 
<Assembly: AssemblyConfiguration("")>
<Assembly: AssemblyCompany("ASCOM Initiative")> 
<Assembly: AssemblyProduct("")> 
<Assembly: AssemblyCopyright("Copyright © $year$")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: AssemblyCulture("")>

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
<Assembly: AssemblyVersion("6.0.0.0")>
<Assembly: AssemblyFileVersion("6.0.0.0")>

<Assembly: ComVisibleAttribute(False)>
