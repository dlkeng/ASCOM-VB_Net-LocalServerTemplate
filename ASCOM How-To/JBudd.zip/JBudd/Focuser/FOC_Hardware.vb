﻿Imports ASCOM
Imports ASCOM.Utilities

' Controller Focus Commands:
' ==========================
' Focus Control/Status
'  HF  - Home Focus (move focus to home position) (response 'OK')
'  QFH - Query Focus Home position
'        (response: 'H:0' = not home, 'H:1' = home)
'  FS+n - Focus Step +'n' steps (move focus 'n' steps in '+' direction) (response 'OK')
'  FS-n - Focus Step -'n' steps (move focus 'n' steps in '-' direction) (response 'OK')
'  FRn  - Focus Rate (set focus step rate to 'n' steps per second) (response 'OK')
'  FMn  - Focus Mode (set focus STEP mode TO 'n' - '0' = half-step, '1' = full-step) (response 'OK')
'
' Temperature Sensing
'  QTn - Query Temperature sensor 'n' temperature value
'        ('n' = 0 - all sensors, 'n' = 1, 2 - individual sensor)
'        (response: 'Tn:xxxx' = DS1820 raw signed hex temperature value)
'
' Other
'  QV  - Query controller firmware version
'        (response: 'V:1.00 1/5/08')

Public Class FOC_Hardware

    Private Const RECEIVE_TIMEOUT As Integer = 2000         ' mS
    Private Const INITIALIZATION_DELAY As Integer = 2500    ' mS

    Private Const HOME_FOCUSER As String = "HF"             ' Home focuser (move focuser to home position)
    Private Const QUERY_FOCUSER_HOME As String = "QFH"      ' Query focuser Home position
    Private Const STEP_FOCUSER_PLUS As String = "FS+"       ' Move focuser + direction
    Private Const STEP_FOCUSER_MINUS As String = "FS-"      ' Move focuser - direction
    Private Const SET_FOCUSER_RATE As String = "FR"         ' Set focuser step rate
    Private Const SET_FOCUSER_MODE As String = "FM"         ' Set focuser step mode
    Private Const QUERY_TEMPERATURE As String = "QT"        ' Query focuser Home temperature
    Private Const QUERY_FW_VERSION As String = "QV"         ' Query controller firmware version

    Private Const OK_RESPONSE As String = "OK"              ' command success response
    Private Const TEMPERATURE_RESPONSE As String = "Tn:"    ' Query temperature response
    Private Const HOME_RESPONSE As String = "H:"            ' Query focuser Home response
    Private Const VERSION_RESPONSE As String = "V:"         ' Query controller firmware response
    Private Const ISHOME_RESPONSE As String = "1"           ' Focuser Home query response
    Private Const UNKNOWN_RESPONSE As String = "???"        ' Unknown response to command/query

    Private Const MIN_FOCUSER_RATE As Integer = 1
    Private Const MAX_FOCUSER_RATE As Integer = 1000
    Private Const HALF_STEP_FOCUSER_MODE As Integer = 0
    Private Const FULL_STEP_FOCUSER_MODE As Integer = 1
    Private Const UNKNOWN_TEMPERATURE As Double = 9999

    Private SerPort As Serial
    Private TL As TraceLogger   ' holds reference to the active trace logger
    Private Utils As New Utilities.Util

    Private _Connected As Boolean = False
    ''' <summary>
    ''' Retrieve serial connected state.
    ''' </summary>
    ''' <returns>serial connected state</returns>
    ''' <remarks></remarks>
    Public ReadOnly Property Connected() As Boolean
        Get
            Return _Connected
        End Get
    End Property

#Region "Focuser Actions"

    ''' <summary>
    ''' Retrieve Focuser controller firmware version.
    ''' </summary>
    ''' <returns>Focuser controller firmware version</returns>
    ''' <remarks></remarks>
    Public ReadOnly Property FirmwareVersion() As String
        Get
            Dim rxMsg As String = CommandString(QUERY_FW_VERSION, False)

            If String.IsNullOrEmpty(rxMsg) Then
                Return UNKNOWN_RESPONSE
            ElseIf Not rxMsg.StartsWith(VERSION_RESPONSE) Then
                Return UNKNOWN_RESPONSE
            Else
                Return rxMsg.Replace(VERSION_RESPONSE, "")
            End If
        End Get
    End Property

    ''' <summary>
    ''' Move Focuser to home position.
    ''' </summary>
    ''' <returns>home Focuser command response</returns>
    ''' <remarks></remarks>
    Public Function HomeFocuser() As String
        Dim rxMsg As String = CommandString(HOME_FOCUSER, False)

        If String.IsNullOrEmpty(rxMsg) Then
            Return UNKNOWN_RESPONSE
        ElseIf Not rxMsg.StartsWith(OK_RESPONSE) Then
            Return UNKNOWN_RESPONSE
        Else
            Return rxMsg
        End If
    End Function

    ''' <summary>
    ''' Set Focuser step rate.
    ''' </summary>
    ''' <param name="rate">1 to 1000</param>
    ''' <returns>set Focuser rate command response</returns>
    ''' <remarks></remarks>
    Public Function SetFocuserRate(rate As Integer) As String
        Dim rxMsg As String

        If (rate < MIN_FOCUSER_RATE) OrElse (rate > MAX_FOCUSER_RATE) Then
            Throw New ASCOM.InvalidValueException("SetFocuserRate", rate.ToString, MIN_FOCUSER_RATE.ToString & " to " & MAX_FOCUSER_RATE.ToString)
        End If

        rxMsg = CommandString(SET_FOCUSER_RATE & rate.ToString, False)
        If String.IsNullOrEmpty(rxMsg) Then
            Return UNKNOWN_RESPONSE
        ElseIf Not rxMsg.StartsWith(OK_RESPONSE) Then
            Return UNKNOWN_RESPONSE
        Else
            Return rxMsg
        End If
    End Function

    ''' <summary>
    ''' Set Focuser step mode.
    ''' </summary>
    ''' <param name="mode">0 = half-step, 1 = full-step</param>
    ''' <returns>set Focuser mode command response</returns>
    ''' <remarks></remarks>
    Public Function SetFocuserMode(mode As Integer) As String
        Dim rxMsg As String

        If (mode <> HALF_STEP_FOCUSER_MODE) AndAlso (mode <> FULL_STEP_FOCUSER_MODE) Then
            Throw New ASCOM.InvalidValueException("SetFocuserMode", mode.ToString, HALF_STEP_FOCUSER_MODE.ToString & " or " & FULL_STEP_FOCUSER_MODE.ToString)
        End If

        rxMsg = CommandString(SET_FOCUSER_MODE & mode.ToString, False)
        If String.IsNullOrEmpty(rxMsg) Then
            Return UNKNOWN_RESPONSE
        ElseIf Not rxMsg.StartsWith(OK_RESPONSE) Then
            Return UNKNOWN_RESPONSE
        Else
            Return rxMsg
        End If
    End Function

    ''' <summary>
    ''' Retrieve Focuser controller temperature.
    ''' </summary>
    ''' <param name="which">0 = both, 1 = temp1, 2 = temp2</param>
    ''' <returns>Focuser controller temperature in °C</returns>
    ''' <remarks>9999 returned if temperature is unknown</remarks>
    Public ReadOnly Property Temperature(which As Integer) As Double
        Get
            Dim response As String = TEMPERATURE_RESPONSE.Replace("n:", which.ToString & ":")
            Dim rxMsg As String = CommandString(QUERY_TEMPERATURE & which.ToString, False)
            Dim temp As Double

            If String.IsNullOrEmpty(rxMsg) Then
                Return UNKNOWN_TEMPERATURE
            ElseIf Not rxMsg.StartsWith(response) Then
                Return UNKNOWN_TEMPERATURE
            Else
                response = rxMsg.Replace(response, "")
                temp = (Convert.ToInt32(response, 16) / 2)  ' from half-°C to °C
                Return temp
            End If
        End Get
    End Property

    ''' <summary>
    ''' Query Focuser for home position.
    ''' </summary>
    ''' <returns>Focuser home state: True = home, False = not home</returns>
    ''' <remarks></remarks>
    Public Function QueryFocuserHome() As Boolean
        Dim rxMsg As String

        rxMsg = CommandString(QUERY_FOCUSER_HOME, False)
        If String.IsNullOrEmpty(rxMsg) Then
            Return False
        ElseIf Not rxMsg.StartsWith(HOME_RESPONSE) Then
            Return False
        Else
            Return rxMsg.Replace(HOME_RESPONSE, "") = ISHOME_RESPONSE
        End If
    End Function

#End Region

    ''' <summary>
    ''' Move Focuser position.
    ''' </summary>
    ''' <param name="steps">+/- amount of steps to move</param>
    ''' <returns>set Focuser move command response</returns>
    ''' <remarks></remarks>
    Public Function Move(steps As Integer) As String
        Dim rxMsg As String

        If (steps < (0 - Focuser.FOCUSER_STEPS)) OrElse (steps > Focuser.FOCUSER_STEPS) Then
            Throw New ASCOM.InvalidValueException("FocuserMove", steps.ToString, "0 to +/- " & Focuser.FOCUSER_STEPS)
        End If

        If steps >= 0 Then      ' sign determines direction of move
            rxMsg = CommandString(STEP_FOCUSER_PLUS & steps.ToString, False)
        Else
            rxMsg = CommandString(STEP_FOCUSER_MINUS & Math.Abs(steps).ToString, False)
        End If
        If String.IsNullOrEmpty(rxMsg) Then
            Return UNKNOWN_RESPONSE
        ElseIf Not rxMsg.StartsWith(OK_RESPONSE) Then
            Return UNKNOWN_RESPONSE
        Else
            Return rxMsg
        End If
    End Function

    ''' <summary>
    ''' Dummy Constructor.
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub New()
        ' so can't be automatically instantiated without parameter
    End Sub

    ''' <summary>
    ''' Constructor.
    ''' </summary>
    ''' <param name="TL">reference to active TraceLogger</param>
    ''' <remarks></remarks>
    Public Sub New(TL As TraceLogger)
        Me.TL = TL
    End Sub

    ''' <summary>
    ''' Open serial port to Focuser.
    ''' </summary>
    ''' <param name="port">serial port name (i.e. COM1, COM2, ...)</param>
    ''' <remarks></remarks>
    Public Sub SerialOpen(port As String)
        SerPort = SharedResources.SharedSerial
        If SharedResources.Connections = 0 Then
            With SerPort
                .PortName = port
                .Parity = SerialParity.None
                .DataBits = 8
                .Speed = SerialSpeed.ps9600
                .StopBits = SerialStopBits.One
                .ReceiveTimeoutMs = RECEIVE_TIMEOUT
                SharedResources.Connected = True
                .ClearBuffers()
            End With
            Utils.WaitForMilliseconds(INITIALIZATION_DELAY)     ' wait for controller to initialize
        Else
            SharedResources.Connected = True
        End If
        TL.LogMessage("SerialOpen(" & port & ")", SharedResources.Connected.ToString)
        _Connected = True
    End Sub

    ''' <summary>
    ''' Close serial port to Focuser.
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub SerialClose()
        If SerPort IsNot Nothing Then
            SharedResources.Connected = False
            TL.LogMessage("SerialClose(" & SerPort.PortName & ")", SharedResources.Connected.ToString)
            SerPort = Nothing
        End If
    End Sub

    ''' <summary>
    ''' Sends command string to Focuser and waits for and returns a response.
    ''' </summary>
    ''' <param name="cmd">command string to send</param>
    ''' <param name="raw">True = 'as-is', False = append CRLF</param>
    ''' <returns>command response</returns>
    ''' <remarks></remarks>
    Public Function CommandString(cmd As String, raw As Boolean) As String
        Dim rxMsg As String = String.Empty

        SyncLock SharedResources.lockObject
            With SerPort
                If .Connected Then
                    Try
                        TL.LogMessage("CommandString", cmd)
                        .ClearBuffers()
                        If raw Then
                            .Transmit(cmd)
                        Else
                            .Transmit(cmd & vbCrLf)
                        End If
                        rxMsg = .ReceiveTerminated(vbCrLf)                  ' get command response
                        TL.LogMessage("CommandString Response:", rxMsg)
                        rxMsg = rxMsg.Replace(vbCrLf, "")
                        .ClearBuffers()
                    Catch ex As System.Runtime.InteropServices.COMException     ' for receive timeout exception
                        TL.LogMessage("--EXCEPTION CommandString(" & cmd & ")", ex.Message)
                        Throw           ' re-Throw exception for application
                    End Try
                End If
            End With
            Return rxMsg
        End SyncLock
    End Function

End Class
