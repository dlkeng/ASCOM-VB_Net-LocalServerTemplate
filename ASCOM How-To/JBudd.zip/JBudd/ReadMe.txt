This is the LocalServer-served ASCOM drivers for a custom Focuser and 
FilterWheel controller.

The local server implements sharing a single serial port on the controller
between the Focuser driver and the FilterWheel driver.
It also limits each driver to 1 client connection at a time.

