<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SetupDialogForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.OK_Button = New System.Windows.Forms.Button()
        Me.Cancel_Button = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.label2 = New System.Windows.Forms.Label()
        Me.chkTrace = New System.Windows.Forms.CheckBox()
        Me.cboComPort = New System.Windows.Forms.ComboBox()
        Me.gbFilters = New System.Windows.Forms.GroupBox()
        Me.txtFilter5Name = New System.Windows.Forms.TextBox()
        Me.txtFilter4Name = New System.Windows.Forms.TextBox()
        Me.txtFilter3Name = New System.Windows.Forms.TextBox()
        Me.txtFilter2Name = New System.Windows.Forms.TextBox()
        Me.txtFilter1Name = New System.Windows.Forms.TextBox()
        Me.txtFocusOffset5 = New System.Windows.Forms.TextBox()
        Me.txtFocusOffset4 = New System.Windows.Forms.TextBox()
        Me.txtFocusOffset3 = New System.Windows.Forms.TextBox()
        Me.txtFocusOffset2 = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtFocusOffset1 = New System.Windows.Forms.TextBox()
        Me.lblFilter5Color = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.lblFilter4Color = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.lblFilter3Color = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.lblFilter2Color = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.lblFilter1Color = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbFilters.SuspendLayout()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.OK_Button, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Cancel_Button, 1, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(150, 301)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(146, 29)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'OK_Button
        '
        Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.OK_Button.Location = New System.Drawing.Point(3, 3)
        Me.OK_Button.Name = "OK_Button"
        Me.OK_Button.Size = New System.Drawing.Size(67, 23)
        Me.OK_Button.TabIndex = 0
        Me.OK_Button.Text = "OK"
        '
        'Cancel_Button
        '
        Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Cancel_Button.Location = New System.Drawing.Point(76, 3)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.Size = New System.Drawing.Size(67, 23)
        Me.Cancel_Button.TabIndex = 1
        Me.Cancel_Button.Text = "Cancel"
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox1.Image = Global.ASCOM.JBudd.My.Resources.Resources.ASCOM
        Me.PictureBox1.Location = New System.Drawing.Point(247, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(48, 56)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Location = New System.Drawing.Point(23, 50)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(50, 13)
        Me.label2.TabIndex = 7
        Me.label2.Text = "Com Port"
        '
        'chkTrace
        '
        Me.chkTrace.AutoSize = True
        Me.chkTrace.Location = New System.Drawing.Point(78, 74)
        Me.chkTrace.Name = "chkTrace"
        Me.chkTrace.Size = New System.Drawing.Size(69, 17)
        Me.chkTrace.TabIndex = 8
        Me.chkTrace.Text = "Trace on"
        Me.chkTrace.UseVisualStyleBackColor = True
        '
        'cboComPort
        '
        Me.cboComPort.FormattingEnabled = True
        Me.cboComPort.Location = New System.Drawing.Point(78, 47)
        Me.cboComPort.Name = "cboComPort"
        Me.cboComPort.Size = New System.Drawing.Size(76, 21)
        Me.cboComPort.TabIndex = 9
        '
        'gbFilters
        '
        Me.gbFilters.Controls.Add(Me.txtFilter5Name)
        Me.gbFilters.Controls.Add(Me.txtFilter4Name)
        Me.gbFilters.Controls.Add(Me.txtFilter3Name)
        Me.gbFilters.Controls.Add(Me.txtFilter2Name)
        Me.gbFilters.Controls.Add(Me.txtFilter1Name)
        Me.gbFilters.Controls.Add(Me.txtFocusOffset5)
        Me.gbFilters.Controls.Add(Me.txtFocusOffset4)
        Me.gbFilters.Controls.Add(Me.txtFocusOffset3)
        Me.gbFilters.Controls.Add(Me.txtFocusOffset2)
        Me.gbFilters.Controls.Add(Me.Label9)
        Me.gbFilters.Controls.Add(Me.txtFocusOffset1)
        Me.gbFilters.Controls.Add(Me.lblFilter5Color)
        Me.gbFilters.Controls.Add(Me.Label19)
        Me.gbFilters.Controls.Add(Me.lblFilter4Color)
        Me.gbFilters.Controls.Add(Me.Label17)
        Me.gbFilters.Controls.Add(Me.lblFilter3Color)
        Me.gbFilters.Controls.Add(Me.Label15)
        Me.gbFilters.Controls.Add(Me.lblFilter2Color)
        Me.gbFilters.Controls.Add(Me.Label13)
        Me.gbFilters.Controls.Add(Me.Label11)
        Me.gbFilters.Controls.Add(Me.Label10)
        Me.gbFilters.Controls.Add(Me.lblFilter1Color)
        Me.gbFilters.Controls.Add(Me.Label1)
        Me.gbFilters.Location = New System.Drawing.Point(17, 110)
        Me.gbFilters.Name = "gbFilters"
        Me.gbFilters.Size = New System.Drawing.Size(276, 175)
        Me.gbFilters.TabIndex = 27
        Me.gbFilters.TabStop = False
        Me.gbFilters.Text = " Filters "
        '
        'txtFilter5Name
        '
        Me.txtFilter5Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtFilter5Name.Location = New System.Drawing.Point(52, 140)
        Me.txtFilter5Name.MaxLength = 16
        Me.txtFilter5Name.Name = "txtFilter5Name"
        Me.txtFilter5Name.Size = New System.Drawing.Size(100, 20)
        Me.txtFilter5Name.TabIndex = 30
        '
        'txtFilter4Name
        '
        Me.txtFilter4Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtFilter4Name.Location = New System.Drawing.Point(52, 112)
        Me.txtFilter4Name.MaxLength = 16
        Me.txtFilter4Name.Name = "txtFilter4Name"
        Me.txtFilter4Name.Size = New System.Drawing.Size(100, 20)
        Me.txtFilter4Name.TabIndex = 29
        '
        'txtFilter3Name
        '
        Me.txtFilter3Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtFilter3Name.Location = New System.Drawing.Point(52, 86)
        Me.txtFilter3Name.MaxLength = 16
        Me.txtFilter3Name.Name = "txtFilter3Name"
        Me.txtFilter3Name.Size = New System.Drawing.Size(100, 20)
        Me.txtFilter3Name.TabIndex = 28
        '
        'txtFilter2Name
        '
        Me.txtFilter2Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtFilter2Name.Location = New System.Drawing.Point(52, 60)
        Me.txtFilter2Name.MaxLength = 16
        Me.txtFilter2Name.Name = "txtFilter2Name"
        Me.txtFilter2Name.Size = New System.Drawing.Size(100, 20)
        Me.txtFilter2Name.TabIndex = 27
        '
        'txtFilter1Name
        '
        Me.txtFilter1Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtFilter1Name.Location = New System.Drawing.Point(52, 34)
        Me.txtFilter1Name.MaxLength = 16
        Me.txtFilter1Name.Name = "txtFilter1Name"
        Me.txtFilter1Name.Size = New System.Drawing.Size(100, 20)
        Me.txtFilter1Name.TabIndex = 23
        '
        'txtFocusOffset5
        '
        Me.txtFocusOffset5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtFocusOffset5.Location = New System.Drawing.Point(210, 140)
        Me.txtFocusOffset5.MaxLength = 6
        Me.txtFocusOffset5.Name = "txtFocusOffset5"
        Me.txtFocusOffset5.Size = New System.Drawing.Size(53, 20)
        Me.txtFocusOffset5.TabIndex = 22
        '
        'txtFocusOffset4
        '
        Me.txtFocusOffset4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtFocusOffset4.Location = New System.Drawing.Point(210, 112)
        Me.txtFocusOffset4.MaxLength = 6
        Me.txtFocusOffset4.Name = "txtFocusOffset4"
        Me.txtFocusOffset4.Size = New System.Drawing.Size(53, 20)
        Me.txtFocusOffset4.TabIndex = 21
        '
        'txtFocusOffset3
        '
        Me.txtFocusOffset3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtFocusOffset3.Location = New System.Drawing.Point(210, 86)
        Me.txtFocusOffset3.MaxLength = 6
        Me.txtFocusOffset3.Name = "txtFocusOffset3"
        Me.txtFocusOffset3.Size = New System.Drawing.Size(53, 20)
        Me.txtFocusOffset3.TabIndex = 20
        '
        'txtFocusOffset2
        '
        Me.txtFocusOffset2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtFocusOffset2.Location = New System.Drawing.Point(210, 60)
        Me.txtFocusOffset2.MaxLength = 6
        Me.txtFocusOffset2.Name = "txtFocusOffset2"
        Me.txtFocusOffset2.Size = New System.Drawing.Size(53, 20)
        Me.txtFocusOffset2.TabIndex = 19
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(203, 18)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(67, 13)
        Me.Label9.TabIndex = 18
        Me.Label9.Text = "Focus Offset"
        '
        'txtFocusOffset1
        '
        Me.txtFocusOffset1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtFocusOffset1.Location = New System.Drawing.Point(210, 34)
        Me.txtFocusOffset1.MaxLength = 6
        Me.txtFocusOffset1.Name = "txtFocusOffset1"
        Me.txtFocusOffset1.Size = New System.Drawing.Size(53, 20)
        Me.txtFocusOffset1.TabIndex = 17
        '
        'lblFilter5Color
        '
        Me.lblFilter5Color.BackColor = System.Drawing.Color.LavenderBlush
        Me.lblFilter5Color.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFilter5Color.Location = New System.Drawing.Point(168, 140)
        Me.lblFilter5Color.Name = "lblFilter5Color"
        Me.lblFilter5Color.Size = New System.Drawing.Size(20, 20)
        Me.lblFilter5Color.TabIndex = 16
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(4, 143)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(38, 13)
        Me.Label19.TabIndex = 14
        Me.Label19.Text = "Filter 5"
        '
        'lblFilter4Color
        '
        Me.lblFilter4Color.BackColor = System.Drawing.Color.LavenderBlush
        Me.lblFilter4Color.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFilter4Color.Location = New System.Drawing.Point(168, 112)
        Me.lblFilter4Color.Name = "lblFilter4Color"
        Me.lblFilter4Color.Size = New System.Drawing.Size(20, 20)
        Me.lblFilter4Color.TabIndex = 13
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(4, 115)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(38, 13)
        Me.Label17.TabIndex = 11
        Me.Label17.Text = "Filter 4"
        '
        'lblFilter3Color
        '
        Me.lblFilter3Color.BackColor = System.Drawing.Color.LavenderBlush
        Me.lblFilter3Color.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFilter3Color.Location = New System.Drawing.Point(168, 86)
        Me.lblFilter3Color.Name = "lblFilter3Color"
        Me.lblFilter3Color.Size = New System.Drawing.Size(20, 20)
        Me.lblFilter3Color.TabIndex = 10
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(4, 89)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(38, 13)
        Me.Label15.TabIndex = 8
        Me.Label15.Text = "Filter 3"
        '
        'lblFilter2Color
        '
        Me.lblFilter2Color.BackColor = System.Drawing.Color.LavenderBlush
        Me.lblFilter2Color.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFilter2Color.Location = New System.Drawing.Point(168, 60)
        Me.lblFilter2Color.Name = "lblFilter2Color"
        Me.lblFilter2Color.Size = New System.Drawing.Size(20, 20)
        Me.lblFilter2Color.TabIndex = 7
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(4, 63)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(38, 13)
        Me.Label13.TabIndex = 5
        Me.Label13.Text = "Filter 2"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(163, 18)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(31, 13)
        Me.Label11.TabIndex = 4
        Me.Label11.Text = "Color"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(50, 15)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(60, 13)
        Me.Label10.TabIndex = 3
        Me.Label10.Text = "Filter Name"
        '
        'lblFilter1Color
        '
        Me.lblFilter1Color.BackColor = System.Drawing.Color.LavenderBlush
        Me.lblFilter1Color.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFilter1Color.Location = New System.Drawing.Point(168, 34)
        Me.lblFilter1Color.Name = "lblFilter1Color"
        Me.lblFilter1Color.Size = New System.Drawing.Size(20, 20)
        Me.lblFilter1Color.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(4, 37)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(38, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Filter 1"
        '
        'SetupDialogForm
        '
        Me.AcceptButton = Me.OK_Button
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.Cancel_Button
        Me.ClientSize = New System.Drawing.Size(308, 342)
        Me.Controls.Add(Me.gbFilters)
        Me.Controls.Add(Me.cboComPort)
        Me.Controls.Add(Me.chkTrace)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "SetupDialogForm"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "JBudd Filter Wheel Setup"
        Me.TableLayoutPanel1.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbFilters.ResumeLayout(False)
        Me.gbFilters.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents OK_Button As System.Windows.Forms.Button
    Friend WithEvents Cancel_Button As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Private WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents chkTrace As System.Windows.Forms.CheckBox
    Friend WithEvents cboComPort As System.Windows.Forms.ComboBox
    Friend WithEvents gbFilters As System.Windows.Forms.GroupBox
    Friend WithEvents txtFilter5Name As System.Windows.Forms.TextBox
    Friend WithEvents txtFilter4Name As System.Windows.Forms.TextBox
    Friend WithEvents txtFilter3Name As System.Windows.Forms.TextBox
    Friend WithEvents txtFilter2Name As System.Windows.Forms.TextBox
    Friend WithEvents txtFilter1Name As System.Windows.Forms.TextBox
    Friend WithEvents txtFocusOffset5 As System.Windows.Forms.TextBox
    Friend WithEvents txtFocusOffset4 As System.Windows.Forms.TextBox
    Friend WithEvents txtFocusOffset3 As System.Windows.Forms.TextBox
    Friend WithEvents txtFocusOffset2 As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtFocusOffset1 As System.Windows.Forms.TextBox
    Friend WithEvents lblFilter5Color As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents lblFilter4Color As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents lblFilter3Color As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents lblFilter2Color As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents lblFilter1Color As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label

End Class
