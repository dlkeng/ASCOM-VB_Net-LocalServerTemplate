Imports System.Windows.Forms
Imports System.Runtime.InteropServices
Imports ASCOM.Utilities
Imports ASCOM.JBudd

<ComVisible(False)> _
Public Class SetupDialogForm

    Private Const FOCUS_OFFSET_MAX_VAL As Integer = 99999
    Private Const FOCUS_OFFSET_MIN_VAL As Integer = -99999

    Private txtFilterName(FilterWheel.MAX_FILTERS - 1) As TextBox
    Private lblFilterColor(FilterWheel.MAX_FILTERS - 1) As Label
    Private txtFocusOffset(FilterWheel.MAX_FILTERS - 1) As TextBox

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click ' OK button event handler
        ' Persist new values of user settings to the ASCOM profile
        FilterWheel.ComPort = cboComPort.Text   ' Update the state variables with results from the dialogue
        FilterWheel.TraceState = chkTrace.Checked
        For ndx As Integer = 0 To FilterWheel.MAX_FILTERS - 1
            FilterWheel.FilterNames(ndx) = txtFilterName(ndx).Text
            FilterWheel.FilterFocusOffsets(ndx) = Integer.Parse(txtFocusOffset(ndx).Text)
        Next
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click 'Cancel button event handler
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub ShowAscomWebPage(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.DoubleClick, PictureBox1.Click
        ' Click on ASCOM logo event handler
        Try
            System.Diagnostics.Process.Start("http://ascom-standards.org/")
        Catch noBrowser As System.ComponentModel.Win32Exception
            If noBrowser.ErrorCode = -2147467259 Then
                MessageBox.Show(noBrowser.Message)
            End If
        Catch other As System.Exception
            MessageBox.Show(other.Message)
        End Try
    End Sub

    Private Sub SetupDialogForm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load ' Form load event handler
        InitControlsArrays()

        cboComPort.Items.Clear()
        Using serial As New ASCOM.Utilities.Serial
            For Each port As String In serial.AvailableCOMPorts
                cboComPort.Items.Add(port)
            Next
        End Using

        ' Retrieve current values of user settings from the ASCOM Profile 
        cboComPort.Text = FilterWheel.ComPort
        chkTrace.Checked = FilterWheel.TraceState
        For ndx As Integer = 0 To FilterWheel.MAX_FILTERS - 1
            txtFilterName(ndx).Text = FilterWheel.FilterNames(ndx)
            lblFilterColor(ndx).BackColor = Drawing.Color.FromName(FilterWheel.FilterNames(ndx))
            txtFocusOffset(ndx).Text = FilterWheel.FilterFocusOffsets(ndx).ToString
        Next
    End Sub

    ' Set up arrays of controls.
    Private Sub InitControlsArrays()
        txtFilterName(0) = txtFilter1Name
        txtFilterName(1) = txtFilter2Name
        txtFilterName(2) = txtFilter3Name
        txtFilterName(3) = txtFilter4Name
        txtFilterName(4) = txtFilter5Name

        lblFilterColor(0) = lblFilter1Color
        lblFilterColor(1) = lblFilter2Color
        lblFilterColor(2) = lblFilter3Color
        lblFilterColor(3) = lblFilter4Color
        lblFilterColor(4) = lblFilter5Color

        txtFocusOffset(0) = txtFocusOffset1
        txtFocusOffset(1) = txtFocusOffset2
        txtFocusOffset(2) = txtFocusOffset3
        txtFocusOffset(3) = txtFocusOffset4
        txtFocusOffset(4) = txtFocusOffset5
    End Sub

    Private Sub txtFilterName_KeyPress(sender As Object, e As System.Windows.Forms.KeyPressEventArgs) _
        Handles txtFilter1Name.KeyPress, txtFilter5Name.KeyPress, txtFilter4Name.KeyPress, txtFilter3Name.KeyPress, txtFilter2Name.KeyPress
        e.Handled = TextBoxFilters.AnyChars_KeyPress(sender, e)
    End Sub

    Private Sub txtFocusOffset_KeyPress(sender As Object, e As System.Windows.Forms.KeyPressEventArgs) _
        Handles txtFocusOffset1.KeyPress, txtFocusOffset5.KeyPress, txtFocusOffset4.KeyPress, txtFocusOffset3.KeyPress, txtFocusOffset2.KeyPress
        e.Handled = TextBoxFilters.SignedNumeric_KeyPress(sender, e)
    End Sub

    Private Sub txtFocusOffset_Leave(sender As Object, e As System.EventArgs) _
        Handles txtFocusOffset1.Leave, txtFocusOffset5.Leave, txtFocusOffset4.Leave, txtFocusOffset3.Leave, txtFocusOffset2.Leave
        Dim txtbx As TextBox = DirectCast(sender, TextBox)

        If txtbx.Text <> String.Empty Then
            If TextBoxFilters.Numeric_Validate(txtbx, FOCUS_OFFSET_MAX_VAL, FOCUS_OFFSET_MIN_VAL) Then
            End If
        End If
    End Sub

End Class
