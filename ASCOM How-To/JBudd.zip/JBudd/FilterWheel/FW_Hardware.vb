﻿Imports ASCOM
Imports ASCOM.Utilities

' Controller Filter Wheel Commands:
' =================================
' Filter Wheel Control/Status
'  MWn - Move filter Wheel 'n' positions (response 'OK')
'  HW  - Home filter Wheel (move filter wheel to home position) (response 'OK')
'  QW  - Query filter Wheel position
'        (response: 'W:0' = home, 'W:1', 'W:2', 'W:3', 'W:4')
'  QWH - Query filter Wheel Home position
'        (response: 'H:0' = not home, 'H:1' = home)
'
' Other
'  QV  - Query controller firmware version
'        (response: 'V:1.00 1/5/08')

Public Class FW_Hardware

    Private Const RECEIVE_TIMEOUT As Integer = 2000         ' mS
    Private Const INITIALIZATION_DELAY As Integer = 2500    ' mS

    Private Const MOVE_FILTER_WHEEL As String = "MW"        ' Move filter Wheel
    Private Const HOME_FILTER_WHEEL As String = "HW"        ' Home filter Wheel (move filter wheel to home position)
    Private Const QUERY_FILTER_WHEEL As String = "QW"       ' Query filter Wheel position
    Private Const QUERY_FILTER_WHEEL_HOME As String = "QWH" ' Query filter Wheel Home position
    Private Const QUERY_FW_VERSION As String = "QV"         ' Query controller firmware version

    Private Const OK_RESPONSE As String = "OK"              ' command success response
    Private Const WHEEL_RESPONSE As String = "W:"           ' Query filter Wheel response
    Private Const HOME_RESPONSE As String = "H:"            ' Query filter Wheel Home response
    Private Const VERSION_RESPONSE As String = "V:"         ' Query controller firmware response
    Private Const ISHOME_RESPONSE As String = "1"           ' Filter Wheel Home query response
    Private Const UNKNOWN_RESPONSE As String = "???"        ' Unknown response to command/query

    Private SerPort As Serial
    Private TL As TraceLogger   ' holds reference to the active trace logger
    Private Utils As New Utilities.Util

    Private _Connected As Boolean = False
    ''' <summary>
    ''' Retrieve serial connected state.
    ''' </summary>
    ''' <returns>serial connected state</returns>
    ''' <remarks></remarks>
    Public ReadOnly Property Connected() As Boolean
        Get
            Return _Connected
        End Get
    End Property

#Region "Focuser Actions"
    ''' <summary>
    ''' Retrieve Filter Wheel controller firmware version.
    ''' </summary>
    ''' <returns>Filter Wheel controller firmware version</returns>
    ''' <remarks></remarks>
    Public ReadOnly Property FirmwareVersion() As String
        Get
            Dim rxMsg As String = CommandString(QUERY_FW_VERSION, False)

            If String.IsNullOrEmpty(rxMsg) Then
                Return UNKNOWN_RESPONSE
            ElseIf Not rxMsg.StartsWith(VERSION_RESPONSE) Then
                Return UNKNOWN_RESPONSE
            Else
                Return rxMsg.Replace(VERSION_RESPONSE, "")
            End If
        End Get
    End Property

    ''' <summary>
    ''' Move Filter Wheel to home position.
    ''' </summary>
    ''' <returns>home Filter Wheel command response</returns>
    ''' <remarks></remarks>
    Public Function HomeFilterWheel() As String
        Dim rxMsg As String = CommandString(HOME_FILTER_WHEEL, False)

        If String.IsNullOrEmpty(rxMsg) Then
            Return UNKNOWN_RESPONSE
        ElseIf Not rxMsg.StartsWith(OK_RESPONSE) Then
            Return UNKNOWN_RESPONSE
        Else
            Return rxMsg
        End If
    End Function
#End Region

    Private _Position As Short = 0
    ''' <summary>
    ''' Get/Set Filter Wheel position.
    ''' </summary>
    ''' <value>Filter Wheel position to move to</value>
    ''' <returns>current Filter Wheel position</returns>
    ''' <remarks>-1 is returned if the Filter Wheel is moving</remarks>
    Public Property Position() As Short
        Get
            Dim rxMsg As String = CommandString(QUERY_FILTER_WHEEL, False)

            If String.IsNullOrEmpty(rxMsg) Then
                Return FilterWheel.FILTERWHEEL_MOVING
            ElseIf Not rxMsg.StartsWith(WHEEL_RESPONSE) Then
                Return FilterWheel.FILTERWHEEL_MOVING
            Else
                rxMsg = rxMsg.Replace(WHEEL_RESPONSE, "")
                _Position = CShort(rxMsg)
            End If
            Return _Position
        End Get
        Set(ByVal value As Short)
            Dim rxMsg As String = String.Empty
            Dim mov As Short

            If (value >= _Position) Then
                mov = value - _Position
            Else
                mov = CShort(FilterWheel.MAX_FILTERS) + value - _Position
            End If
            If mov <> 0 Then
                rxMsg = CommandString(MOVE_FILTER_WHEEL & mov.ToString, False)
                '_Position = FilterWheel.FILTERWHEEL_MOVING
                If rxMsg.StartsWith(OK_RESPONSE) Then
                    _Position = value
                End If
            End If
        End Set
    End Property

    ''' <summary>
    ''' Dummy Constructor.
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub New()
        ' so can't be automatically instantiated without parameter
    End Sub

    ''' <summary>
    ''' Constructor.
    ''' </summary>
    ''' <param name="TL">reference to active TraceLogger</param>
    ''' <remarks></remarks>
    Public Sub New(TL As TraceLogger)
        Me.TL = TL
    End Sub

    ''' <summary>
    ''' Open serial port to Filter Wheel.
    ''' </summary>
    ''' <param name="port">serial port name (i.e. COM1, COM2, ...)</param>
    ''' <remarks></remarks>
    Public Sub SerialOpen(port As String)
        SerPort = SharedResources.SharedSerial
        If SharedResources.Connections = 0 Then
            With SerPort
                .PortName = port
                .Parity = SerialParity.None
                .DataBits = 8
                .Speed = SerialSpeed.ps9600
                .StopBits = SerialStopBits.One
                .ReceiveTimeoutMs = RECEIVE_TIMEOUT
                SharedResources.Connected = True
                .ClearBuffers()
            End With
            Utils.WaitForMilliseconds(INITIALIZATION_DELAY)     ' wait for controller to initialize
        Else
            SharedResources.Connected = True
        End If
        TL.LogMessage("SerialOpen(" & port & ")", SharedResources.Connected.ToString)
        _Connected = True
    End Sub

    ''' <summary>
    ''' Close serial port to Filter Wheel.
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub SerialClose()
        If SerPort IsNot Nothing Then
            SharedResources.Connected = False
            TL.LogMessage("SerialClose(" & SerPort.PortName & ")", SharedResources.Connected.ToString)
            SerPort = Nothing
        End If
    End Sub

    ''' <summary>
    ''' Sends command string to Filter Wheel and waits for and returns a response.
    ''' </summary>
    ''' <param name="cmd">command string to send</param>
    ''' <param name="raw">True = 'as-is', False = append CRLF</param>
    ''' <returns>command response</returns>
    ''' <remarks></remarks>
    Public Function CommandString(cmd As String, raw As Boolean) As String
        Dim rxMsg As String = String.Empty

        SyncLock SharedResources.lockObject
            With SerPort
                If .Connected Then
                    Try
                        TL.LogMessage("CommandString", cmd)
                        .ClearBuffers()
                        If raw Then
                            .Transmit(cmd)
                        Else
                            .Transmit(cmd & vbCrLf)
                        End If
                        rxMsg = .ReceiveTerminated(vbCrLf)                  ' get command response
                        TL.LogMessage("CommandString Response:", rxMsg)
                        rxMsg = rxMsg.Replace(vbCrLf, "")
                        .ClearBuffers()
                    Catch ex As System.Runtime.InteropServices.COMException     ' for receive timeout exception
                        TL.LogMessage("--EXCEPTION CommandString(" & cmd & ")", ex.Message)
                        Throw           ' re-Throw exception for application
                    End Try
                End If
            End With
            Return rxMsg
        End SyncLock
    End Function

End Class
