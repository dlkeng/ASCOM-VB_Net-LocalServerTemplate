'tabs=4
'
' NOTE: MUST BE RUN AS ADMINISTRATOR!!!!
'
' --------------------------------------------------------------------------------
'
' ASCOM FilterWheel driver for JBudd
'
' Description:	ASCOM FilterWheel driver for J. Budden filterwheel.
'
' Implements:	ASCOM FilterWheel interface version: 1.0
' Author:		(DLK) Your N. Here <your@email.here>
'
' Edit Log:
'
' Date			Who	Vers	Description
' -----------	---	-----	-------------------------------------------------------
' 20-JAN-2015	DLK	1.0.0	Initial edit, from FilterWheel template
' ---------------------------------------------------------------------------------
'
' Your driver's ID is ASCOM.JBudd.FilterWheel
'
' The Guid attribute sets the CLSID for ASCOM.DeviceName.FilterWheel
' The ClassInterface/None attribute prevents an empty interface called
' _FilterWheel from being created and used as the [default] interface
'
Imports ASCOM
Imports ASCOM.Astrometry
Imports ASCOM.Astrometry.AstroUtils
Imports ASCOM.DeviceInterface
Imports ASCOM.Utilities

Imports System
Imports System.Collections
Imports System.Collections.Generic
Imports System.Globalization
Imports System.Runtime.InteropServices
Imports System.Text

Friend Class FilterWheelLocalServerConstants
    Friend Const DRIVER_ID As String = "ASCOM.JBudd.FilterWheel"
    Friend Const DRIVER_DESCRIPTION As String = "JBudd FilterWheel"
End Class

<Guid("ad811902-5489-422c-89b3-b14726406c8c")> _
<ProgId(FilterWheelLocalServerConstants.DRIVER_ID)> _
<ServedClassName(FilterWheelLocalServerConstants.DRIVER_DESCRIPTION)> _
<ClassInterface(ClassInterfaceType.None)> _
Public Class FilterWheel
    Inherits ReferenceCountedObjectBase
    Implements IFilterWheelV2

    ' The Guid attribute sets the CLSID for ASCOM.JBudd.FilterWheel
    ' The ClassInterface/None addribute prevents an empty interface called
    ' _JBudd from being created and used as the [default] interface

    Friend Const DEVICE_TYPE As String = "FilterWheel"
    Friend Const MAX_FILTERS As Integer = 5
    Friend Const FILTERWHEEL_MOVING As Integer = -1
    Friend Const ACTION_FIRMWARE_VERSION As String = DEVICE_TYPE & ":FirmwareVersion"
    Friend Const ACTION_HOME_WHEEL As String = DEVICE_TYPE & ":HomeWheel"

    '
    ' Driver ID and descriptive string that shows in the Chooser
    '
    Friend Shared DriverID As String = FilterWheelLocalServerConstants.DRIVER_ID
    Private Shared DriverDescription As String = FilterWheelLocalServerConstants.DRIVER_DESCRIPTION
    Private Const DriverInterfaceVersion As Integer = 2

    'Constants used for Profile persistence
    Private Shared ComPortProfileName As String = "COM Port"
    Private Shared TraceStateProfileName As String = "Trace Level"
    Private Shared FilterNamesProfileName As String = "Filter Names"
    Private Shared FilterFocusOffsetsProfileName As String = "Filter Focus Offsets"

    Private Shared ComPortDefault As String = "COM23"
    Private Shared TraceStateDefault As String = "True"
    Private Shared FilterNamesDefaults As String() = New String(MAX_FILTERS - 1) {"Red", "Green", "Blue", "Clear", "Black"}
    Private Shared FilterFocusOffsetsDefaults As Integer() = New Integer(MAX_FILTERS - 1) {0, 0, 0, 0, 0}
    Private Shared FilterWheelSupportedActions As New ArrayList(New String() {ACTION_FIRMWARE_VERSION, ACTION_HOME_WHEEL})

    ' Variables to hold the currrent device configuration
    Friend Shared ComPort As String
    Friend Shared TraceState As Boolean
    Friend Shared FilterNames(MAX_FILTERS - 1) As String
    Friend Shared FilterFocusOffsets(MAX_FILTERS - 1) As Integer

    Private ConnectedState As Boolean       ' Private variable to hold the connected state
    Private Utilities As Util               ' Private variable to hold an ASCOM Utilities object
    Private AstroUtilities As AstroUtils    ' Private variable to hold an AstroUtils object to provide the Range method
    Private TL As TraceLogger ' Private variable to hold the trace logger object (creates a diagnostic log file with information that you specify)

    Private FW As FW_Hardware

    ''' <summary>
    ''' Constructor - Must be public for COM registration!
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub New()

        ReadProfile()                   ' Read device configuration from the ASCOM Profile store
        TL = New TraceLogger("", "JBudd")
        TL.Enabled = TraceState
        TL.LogMessage(DEVICE_TYPE, "Starting initialization")

        ConnectedState = False          ' Initialize connected to false
        Utilities = New Util()          ' Initialize util object
        AstroUtilities = New AstroUtils ' Initialize new astro utilities object

        FW = New FW_Hardware(TL)

        TL.LogMessage(DEVICE_TYPE, "Completed initialization")
    End Sub

    '
    ' PUBLIC COM INTERFACE IFilterWheelV2 IMPLEMENTATION
    '
#Region "Common properties and methods"
    ''' <summary>
    ''' Displays the Setup Dialog form.
    ''' If the user clicks the OK button to dismiss the form, then
    ''' the new settings are saved, otherwise the old values are reloaded.
    ''' THIS IS THE ONLY PLACE WHERE SHOWING USER INTERFACE IS ALLOWED!
    ''' </summary>
    Public Sub SetupDialog() Implements IFilterWheelV2.SetupDialog
        ' consider only showing the setup dialog if not connected
        ' or call a different dialog if connected
        If IsConnected Then
            System.Windows.Forms.MessageBox.Show("Already connected, just press OK")
        End If

        Using F As SetupDialogForm = New SetupDialogForm()
            Dim result As System.Windows.Forms.DialogResult = F.ShowDialog()
            If result = DialogResult.OK Then
                WriteProfile()  ' Persist device configuration values to the ASCOM Profile store
            End If
        End Using
    End Sub

    ''' <summary>
    ''' Retrieve list of supported actions.
    ''' </summary>
    ''' <returns>list of supported actions</returns>
    ''' <remarks></remarks>
    Public ReadOnly Property SupportedActions() As ArrayList Implements IFilterWheelV2.SupportedActions
        Get
            Dim ndx As Integer = 0

            For Each action As String In FilterWheelSupportedActions  ' Write filter actions to the log
                TL.LogMessage("SupportedActions Get" & ndx.ToString, action)
                ndx += 1
            Next
            Return FilterWheelSupportedActions
        End Get
    End Property

    ''' <summary>
    ''' Execute a specified Action.
    ''' </summary>
    ''' <param name="ActionName">name of the Action to execute</param>
    ''' <param name="ActionParameters">parameter to the Action to execute</param>
    ''' <returns>response to Action execution</returns>
    ''' <remarks></remarks>
    Public Function Action(ByVal ActionName As String, ByVal ActionParameters As String) As String Implements IFilterWheelV2.Action
        Dim response As String = String.Empty

        If Not FilterWheelSupportedActions.Contains(ActionName) Then
            Throw New ActionNotImplementedException("Action " & ActionName & " is not supported by this driver")
        Else
            TL.LogMessage("Action Execute", ActionName)
            Select Case ActionName
                Case ACTION_FIRMWARE_VERSION
                    response = FW.FirmwareVersion
                Case ACTION_HOME_WHEEL
                    response = FW.HomeFilterWheel()
            End Select
        End If
        TL.LogMessage("Action Response", response)
        Return response
    End Function

    ''' <summary>
    ''' Sends an arbitrary string to the device and does not wait for a response.
    ''' </summary>
    ''' <param name="Command">string to send</param>
    ''' <param name="Raw">True = 'as-is', False = append CRLF</param>
    ''' <remarks></remarks>
    Public Sub CommandBlind(ByVal Command As String, Optional ByVal Raw As Boolean = False) _
        Implements IFilterWheelV2.CommandBlind
        CheckConnected("CommandBlind")
        ' Call CommandString and return as soon as it finishes
        Me.CommandString(Command, Raw)
    End Sub

    ''' <summary>
    ''' Sends an arbitrary string to the device and waits for a Boolean response.
    ''' </summary>
    ''' <param name="Command">string to send</param>
    ''' <param name="Raw">True = 'as-is', False = append CRLF</param>
    ''' <returns>command response</returns>
    ''' <remarks>Not Implemented</remarks>
    Public Function CommandBool(ByVal Command As String, Optional ByVal Raw As Boolean = False) As Boolean _
        Implements IFilterWheelV2.CommandBool
        CheckConnected("CommandBool")
        Throw New MethodNotImplementedException("CommandBool")
    End Function

    ''' <summary>
    ''' Sends an arbitrary string to the device and waits for a string response.
    ''' </summary>
    ''' <param name="Command">string to send</param>
    ''' <param name="Raw">True = 'as-is', False = append CRLF</param>
    ''' <returns>command response</returns>
    ''' <remarks></remarks>
    Public Function CommandString(ByVal Command As String, Optional ByVal Raw As Boolean = False) As String _
        Implements IFilterWheelV2.CommandString
        CheckConnected("CommandString")
        ' it's a good idea to put all the low level communication with the device here,
        ' then all communication calls this function
        ' you need something to ensure that only one command is in progress at a time
        Return FW.CommandString(Command, Raw)
    End Function

    ''' <summary>
    ''' Connect or disconnect the device.
    ''' </summary>
    ''' <value>True = connect, False = disconnect</value>
    ''' <returns>connected status</returns>
    ''' <remarks>opens/closes the connection to the device</remarks>
    Public Property Connected() As Boolean Implements IFilterWheelV2.Connected
        Get
            TL.LogMessage("Connected Get1", IsConnected.ToString())
            Return IsConnected
        End Get
        Set(value As Boolean)
            TL.LogMessage("Connected Set1(" & SharedResources.IsConnected(DriverID) & ")", _
                          value.ToString() & "'" & DriverID & "'")
            If value AndAlso SharedResources.IsConnected(DriverID) Then
                Throw New InvalidOperationException("Only 1 connection allowed at a time!")
            End If
            If value = IsConnected Then
                Return
            End If

            If value Then
                If (FW IsNot Nothing) AndAlso (FW.Connected) Then
                    Return
                End If

                TL.LogMessage("Connected Set2", "Connecting application to device")
                Try
                    FW.SerialOpen(ComPort)   ' connect to the device
                    ConnectedState = True
                    SharedResources.Connect(DriverID)
                Catch ex As Exception
                    Throw New NotConnectedException(ex.Message)
                End Try
            Else
                ConnectedState = False
                TL.LogMessage("Connected Set3", "Disconnecting application from device")
                Try
                    SharedResources.Disconnect(DriverID)
                    FW.SerialClose()         ' disconnect from the device
                Catch ex As Exception
                    Throw           ' re-Throw exception for application
                End Try
            End If
        End Set
    End Property

    ''' <summary>
    ''' Retrieve the description of the device.
    ''' </summary>
    ''' <returns>description of the device</returns>
    ''' <remarks></remarks>
    Public ReadOnly Property Description As String Implements IFilterWheelV2.Description
        Get
            TL.LogMessage("Description Get", DriverDescription)
            Return DriverDescription
        End Get
    End Property

    ''' <summary>
    ''' Retrieve the driver version information.
    ''' </summary>
    ''' <returns>driver version information</returns>
    ''' <remarks></remarks>
    Public ReadOnly Property DriverInfo As String Implements IFilterWheelV2.DriverInfo
        Get
            Dim m_version As Version = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version
            Dim s_driverInfo As String = "ASCOM Version: " & m_version.Major.ToString() & "." & m_version.Minor.ToString()
            TL.LogMessage("DriverInfo Get", s_driverInfo)
            Return s_driverInfo
        End Get
    End Property

    ''' <summary>
    ''' Retrieve the ASCOM version supported.
    ''' </summary>
    ''' <returns>ASCOM version supported</returns>
    ''' <remarks></remarks>
    Public ReadOnly Property DriverVersion() As String Implements IFilterWheelV2.DriverVersion
        Get
            ' Get our own assembly and report its version number
            TL.LogMessage("DriverVersion Get", Reflection.Assembly.GetExecutingAssembly.GetName.Version.ToString(2))
            Return Reflection.Assembly.GetExecutingAssembly.GetName.Version.ToString(2)
        End Get
    End Property

    ''' <summary>
    ''' Retrieve the driver interface version supported.
    ''' </summary>
    ''' <returns>driver interface version supported</returns>
    ''' <remarks></remarks>
    Public ReadOnly Property InterfaceVersion() As Short Implements IFilterWheelV2.InterfaceVersion
        Get
            TL.LogMessage("InterfaceVersion Get", DriverInterfaceVersion.ToString)
            Return DriverInterfaceVersion
        End Get
    End Property

    ''' <summary>
    ''' Retrieve the short name for the driver.
    ''' </summary>
    ''' <returns>short name for the driver</returns>
    ''' <remarks></remarks>
    Public ReadOnly Property Name As String Implements IFilterWheelV2.Name
        Get
            Dim s_name As String = "JBudd " & DEVICE_TYPE

            TL.LogMessage("Name Get", s_name)
            Return s_name
        End Get
    End Property

    ''' <summary>
    ''' Releases the driver items.
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Dispose() Implements IFilterWheelV2.Dispose
        ' Clean up the tracelogger and util objects
        TL.Enabled = False
        TL.Dispose()
        TL = Nothing
        Utilities.Dispose()
        Utilities = Nothing
        AstroUtilities.Dispose()
        AstroUtilities = Nothing
    End Sub

#End Region

#Region "IFilterWheel Implementation"
    Private fwPosition As Short = 0 'class level variable to retain the current filterwheel position

    '''
    ''' <summary>
    ''' Retrieves the focus offset of each filter in the Filter Wheel.
    ''' </summary>
    ''' <returns>array of Filter Wheel focus offsets</returns>
    ''' <remarks></remarks>
    Public ReadOnly Property FocusOffsets() As Integer() Implements IFilterWheelV2.FocusOffsets
        Get
            Dim ndx As Integer = 0

            ' Write filter focus offsets to the log
            For Each fwOffset As Integer In FilterFocusOffsets
                TL.LogMessage("FocusOffsets Get" & ndx.ToString, fwOffset.ToString())
                ndx += 1
            Next

            Return FilterFocusOffsets
        End Get
    End Property

    '''
    ''' <summary>
    ''' Retrieves the name of each filter in the Filter Wheel. 
    ''' </summary>
    ''' <returns>array of filter names</returns>
    ''' <remarks></remarks>
    Public ReadOnly Property Names As String() Implements IFilterWheelV2.Names
        Get
            Dim ndx As Integer = 0

            ' Write filter names to the log
            For Each fwName As String In FilterNames
                TL.LogMessage("Names Get" & ndx.ToString, fwName)
                ndx += 1
            Next

            Return FilterNames
        End Get
    End Property

    ''' <summary>
    ''' Sets or returns the current Filter Wheel position.
    ''' </summary>
    ''' <value>Filter Wheel position to move to</value>
    ''' <returns>current Filter Wheel position</returns>
    ''' <remarks>-1 is returned if the Filter Wheel is moving</remarks>
    Public Property Position() As Short Implements IFilterWheelV2.Position
        Get
            CheckConnected("Position Get")
            fwPosition = FW.Position
            TL.LogMessage("Position Get", fwPosition.ToString())
            Return fwPosition
        End Get
        Set(value As Short)
            TL.LogMessage("Position Set", value.ToString())
            CheckConnected("Position Set")
            If ((value < 0) OrElse (value > MAX_FILTERS - 1)) Then
                TL.LogMessage("Position Set", "Throwing InvalidValueException")
                Throw New InvalidValueException("Position", value.ToString(), "0 to " & (FilterNames.Length - 1).ToString())
            End If
            FW.Position = value
            fwPosition = value
        End Set
    End Property

#End Region

#Region "Private properties and methods"
    ' here are some useful properties and methods that can be used as required
    ' to help with driver development

    ''' <summary>
    ''' Returns true if there is a valid connection to the driver hardware.
    ''' </summary>
    Private ReadOnly Property IsConnected As Boolean
        Get
            ' TODO check that the driver hardware connection exists and is connected to the hardware
            Return ConnectedState
        End Get
    End Property

    ''' <summary>
    ''' Use this function to throw an exception if we aren't connected to the hardware.
    ''' </summary>
    ''' <param name="message">message to include in the exception</param>
    Private Sub CheckConnected(ByVal message As String)
        If Not IsConnected Then
            Throw New NotConnectedException(message)
        End If
    End Sub

    ''' <summary>
    ''' Read the device configuration from the ASCOM Profile store (or load defaults).
    ''' </summary>
    Friend Sub ReadProfile()
        Using driverProfile As New Profile()
            driverProfile.DeviceType = DEVICE_TYPE
            TraceState = Convert.ToBoolean(driverProfile.GetValue(DriverID, TraceStateProfileName, String.Empty, TraceStateDefault))
            ComPort = driverProfile.GetValue(DriverID, ComPortProfileName, String.Empty, ComPortDefault)
            For ndx As Integer = 0 To MAX_FILTERS - 1
                FilterNames(ndx) = driverProfile.GetValue(DriverID, ndx.ToString, FilterNamesProfileName, FilterNamesDefaults(ndx))
                Integer.TryParse(driverProfile.GetValue(DriverID, ndx.ToString, FilterFocusOffsetsProfileName, FilterFocusOffsetsDefaults(ndx).ToString), FilterFocusOffsets(ndx))
            Next
        End Using
    End Sub

    ''' <summary>
    ''' Write the device configuration to the ASCOM Profile store.
    ''' </summary>
    Friend Sub WriteProfile()
        Using driverProfile As New Profile()
            driverProfile.DeviceType = DEVICE_TYPE
            driverProfile.WriteValue(DriverID, TraceStateProfileName, TraceState.ToString())
            driverProfile.WriteValue(DriverID, ComPortProfileName, ComPort.ToString())
            For ndx As Integer = 0 To MAX_FILTERS - 1
                driverProfile.WriteValue(DriverID, ndx.ToString, FilterNames(ndx), FilterNamesProfileName)
                driverProfile.WriteValue(DriverID, ndx.ToString, FilterFocusOffsets(ndx).ToString, FilterFocusOffsetsProfileName)
            Next
        End Using
    End Sub

#End Region

End Class
