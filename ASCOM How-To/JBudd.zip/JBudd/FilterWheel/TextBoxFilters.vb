' Common TextBox filters and value validators.

Public Class TextBoxFilters

#Region "Keypress Filters"

    ' Any characters
    Public Shared Function AnyChars_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) As Boolean
        Dim txtbx As TextBox

        If e.KeyChar = ChrW(Keys.Return) Then
            SendKeys.Send("{TAB}")
            Return True
        ElseIf e.KeyChar = ChrW(Keys.Escape) Then
            txtbx = TryCast(sender, TextBox)
            If txtbx IsNot Nothing Then
                txtbx.Clear()
                Return True
            End If
        End If
        Return False
    End Function

    ' Unsigned numeric chars only
    Public Shared Function Numeric_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) As Boolean
        Dim txtbx As TextBox = DirectCast(sender, TextBox)

        If e.KeyChar = ChrW(Keys.Return) Then
            SendKeys.Send("{TAB}")
            Return True
        ElseIf e.KeyChar = ChrW(Keys.Escape) Then
            txtbx.Clear()
            Return True
        ElseIf (e.KeyChar < "0"c) OrElse (e.KeyChar > "9") Then
            If e.KeyChar <> ChrW(Keys.Back) Then     ' Allow BackSpace
                Return True
            End If
        End If
        Return False
    End Function

    ' Signed numeric chars only
    Public Shared Function SignedNumeric_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) As Boolean
        Dim txtbx As TextBox = DirectCast(sender, TextBox)

        If e.KeyChar = ChrW(Keys.Return) Then
            SendKeys.Send("{TAB}")
            Return True
        ElseIf e.KeyChar = ChrW(Keys.Escape) Then
            txtbx.Clear()
            Return True
        ElseIf e.KeyChar = "-"c Then
            If (txtbx.SelectionStart <> 0) OrElse ((txtbx.Text.Contains("-") AndAlso Not txtbx.SelectedText.Contains("-"))) Then
                Return True ' don't allow except as 1st char in TextBox
            Else
                ' allow it
            End If
        ElseIf (e.KeyChar < "0"c) OrElse (e.KeyChar > "9") Then
            If e.KeyChar <> ChrW(Keys.Back) Then     ' Allow BackSpace
                Return True
            End If
        End If
        Return False
    End Function

    ' Unsigned numeric & decimal point only
    Public Shared Function UnsignedDecimal_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) As Boolean
        Dim txtbx As TextBox = DirectCast(sender, TextBox)

        If e.KeyChar = ChrW(Keys.Return) Then
            SendKeys.Send("{TAB}")
            Return True
        ElseIf e.KeyChar = ChrW(Keys.Escape) Then
            txtbx.Clear()
            Return True
        ElseIf e.KeyChar = "."c Then
            If txtbx.Text.Contains(".") Then
                Return True ' don't allow more than 1
            Else
                ' allow it
            End If
        ElseIf (e.KeyChar < "0"c) OrElse (e.KeyChar > "9") Then
            If e.KeyChar <> ChrW(Keys.Back) Then     ' Allow BackSpace
                Return True
            End If
        End If
    End Function

    ' Signed numeric & decimal point only
    Public Shared Function SignedDecimal_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) As Boolean
        Dim txtbx As TextBox = DirectCast(sender, TextBox)

        If e.KeyChar = ChrW(Keys.Return) Then
            SendKeys.Send("{TAB}")
            Return True
        ElseIf e.KeyChar = ChrW(Keys.Escape) Then
            txtbx.Clear()
            Return True
        ElseIf e.KeyChar = "."c Then
            If txtbx.Text.Contains(".") Then
                Return True ' don't allow more than 1
            Else
                ' allow it
            End If
        ElseIf e.KeyChar = "-"c Then
            If (txtbx.SelectionStart <> 0) OrElse ((txtbx.Text.Contains("-") AndAlso Not txtbx.SelectedText.Contains("-"))) Then
                Return True ' don't allow except as 1st char in TextBox
            Else
                ' allow it
            End If
        ElseIf (e.KeyChar < "0"c) OrElse (e.KeyChar > "9") Then
            If e.KeyChar <> ChrW(Keys.Back) Then     ' Allow BackSpace
                Return True
            End If
        End If
    End Function

#End Region

#Region "TextBox Values Validators"

    ' Unsigned numeric chars only
    '  Return: True = TextBox value OK, False = TextBox value not OK
    Public Shared Function Numeric_Validate(ByVal txtbx As TextBox, ByVal maxval As Integer, ByVal minval As Integer) As Boolean
        Dim txtval As Integer

        If txtbx.Text <> String.Empty Then
            txtval = Integer.Parse(txtbx.Text)
            If (txtval < minval) OrElse (txtval > maxval) Then
                Beep()
                MsgBox("Invalid value", MsgBoxStyle.OkOnly Or MsgBoxStyle.Exclamation, "Bounds Check")
                txtbx.SelectionStart = 0
                txtbx.SelectionLength = txtbx.MaxLength
                txtbx.Focus()
                Return False
            End If
        End If
        Return True

    End Function

    ' Signed numeric chars only
    '  Return: True = TextBox value OK, False = TextBox value not OK
    Public Shared Function SignedNumeric_Validate(ByVal txtbx As TextBox, ByVal maxval As Integer, ByVal minval As Integer) As Boolean
        Dim txtval As Integer

        If txtbx.Text <> String.Empty Then
            If txtbx.Text = "-" Then
                txtval = maxval + 1
            Else
                txtval = Integer.Parse(txtbx.Text)
            End If
            If (txtval < minval) OrElse (txtval > maxval) Then
                Beep()
                MsgBox("Invalid value", MsgBoxStyle.OkOnly Or MsgBoxStyle.Exclamation, "Bounds Check")
                txtbx.SelectionStart = 0
                txtbx.SelectionLength = txtbx.MaxLength
                txtbx.Focus()
                Return False
            End If
            Return True

        End If

    End Function

    ' Unsigned numeric & decimal point only
    '  Return: True = TextBox value OK, False = TextBox value not OK
    Public Shared Function UnsignedDecimal_Validate(ByVal txtbx As TextBox, ByVal maxval As Single, ByVal minval As Single) As Boolean
        Dim txtval As Single

        If txtbx.Text <> String.Empty Then
            If txtbx.Text = "." Then
                txtval = maxval + 1
            Else
                txtval = Single.Parse(txtbx.Text)
            End If
            If (txtval < minval) OrElse (txtval > maxval) Then
                Beep()
                MsgBox("Invalid value", MsgBoxStyle.OkOnly Or MsgBoxStyle.Exclamation, "Bounds Check")
                txtbx.SelectionStart = 0
                txtbx.SelectionLength = txtbx.MaxLength
                txtbx.Focus()
                Return False
            End If
        End If
        Return True

    End Function

    ' Signed numeric & decimal point only
    '  Return: True = TextBox value OK, False = TextBox value not OK
    Public Shared Function SignedDecimal_Validate(ByVal txtbx As TextBox, ByVal maxval As Single, ByVal minval As Single) As Boolean
        Dim txtval As Single

        If txtbx.Text <> String.Empty Then
            If (txtbx.Text = "-") OrElse (txtbx.Text = ".") OrElse (txtbx.Text = "-.") Then
                txtval = maxval + 1
            Else
                txtval = Single.Parse(txtbx.Text)
            End If
            If (txtval < minval) OrElse (txtval > maxval) Then
                Beep()
                MsgBox("Invalid value", MsgBoxStyle.OkOnly Or MsgBoxStyle.Exclamation, "Bounds Check")
                txtbx.SelectionStart = 0
                txtbx.SelectionLength = txtbx.MaxLength
                txtbx.Focus()
                Return False
            End If
        End If
        Return True

    End Function


#End Region

End Class
