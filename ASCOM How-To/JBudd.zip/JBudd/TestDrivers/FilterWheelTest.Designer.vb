﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TestFilterWheelForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnConnect = New System.Windows.Forms.Button()
        Me.btnChoose = New System.Windows.Forms.Button()
        Me.labelDriverId = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.chkConnected = New System.Windows.Forms.CheckBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblDescription = New System.Windows.Forms.Label()
        Me.lblDriverInfo = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lblInterfaceVersion = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblName = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.gbProperties = New System.Windows.Forms.GroupBox()
        Me.lblSupportedActionsList = New System.Windows.Forms.Label()
        Me.lblSupportedActions = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.lblPosition = New System.Windows.Forms.Label()
        Me.lblDriverVersion = New System.Windows.Forms.Label()
        Me.gbFilters = New System.Windows.Forms.GroupBox()
        Me.lblFocusOffset1 = New System.Windows.Forms.Label()
        Me.lblFilter5Name = New System.Windows.Forms.Label()
        Me.lblFilter4Name = New System.Windows.Forms.Label()
        Me.lblFilter3Name = New System.Windows.Forms.Label()
        Me.lblFilter2Name = New System.Windows.Forms.Label()
        Me.lblFilter1Name = New System.Windows.Forms.Label()
        Me.lblFocusOffset5 = New System.Windows.Forms.Label()
        Me.lblFocusOffset4 = New System.Windows.Forms.Label()
        Me.lblFocusOffset3 = New System.Windows.Forms.Label()
        Me.lblFocusOffset2 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.lblFilter5Color = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.lblFilter4Color = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.lblFilter3Color = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.lblFilter2Color = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.lblFilter1Color = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.pnlNavs = New System.Windows.Forms.Panel()
        Me.lblCurrentFilter = New System.Windows.Forms.Label()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.btnPrev = New System.Windows.Forms.Button()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.lblFirmwareVersion = New System.Windows.Forms.Label()
        Me.gbProperties.SuspendLayout()
        Me.gbFilters.SuspendLayout()
        Me.pnlNavs.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnConnect
        '
        Me.btnConnect.Location = New System.Drawing.Point(316, 36)
        Me.btnConnect.Name = "btnConnect"
        Me.btnConnect.Size = New System.Drawing.Size(72, 23)
        Me.btnConnect.TabIndex = 4
        Me.btnConnect.Text = "Connect"
        Me.btnConnect.UseVisualStyleBackColor = True
        '
        'btnChoose
        '
        Me.btnChoose.Location = New System.Drawing.Point(316, 7)
        Me.btnChoose.Name = "btnChoose"
        Me.btnChoose.Size = New System.Drawing.Size(72, 23)
        Me.btnChoose.TabIndex = 3
        Me.btnChoose.Text = "Choose"
        Me.btnChoose.UseVisualStyleBackColor = True
        '
        'labelDriverId
        '
        Me.labelDriverId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.labelDriverId.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.ASCOM.JBudd.My.MySettings.Default, "FilterWheelDriverId", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.labelDriverId.Location = New System.Drawing.Point(12, 37)
        Me.labelDriverId.Name = "labelDriverId"
        Me.labelDriverId.Size = New System.Drawing.Size(291, 21)
        Me.labelDriverId.TabIndex = 5
        Me.labelDriverId.Tag = ""
        Me.labelDriverId.Text = Global.ASCOM.JBudd.My.MySettings.Default.FilterWheelDriverId
        Me.labelDriverId.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(10, 21)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(50, 13)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Driver Id:"
        '
        'chkConnected
        '
        Me.chkConnected.AutoCheck = False
        Me.chkConnected.AutoSize = True
        Me.chkConnected.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkConnected.Location = New System.Drawing.Point(11, 22)
        Me.chkConnected.Name = "chkConnected"
        Me.chkConnected.Size = New System.Drawing.Size(81, 17)
        Me.chkConnected.TabIndex = 7
        Me.chkConnected.Text = "Connected:"
        Me.chkConnected.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkConnected.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(8, 46)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(63, 13)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Description:"
        '
        'lblDescription
        '
        Me.lblDescription.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblDescription.Location = New System.Drawing.Point(77, 47)
        Me.lblDescription.Name = "lblDescription"
        Me.lblDescription.Size = New System.Drawing.Size(285, 34)
        Me.lblDescription.TabIndex = 10
        '
        'lblDriverInfo
        '
        Me.lblDriverInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblDriverInfo.Location = New System.Drawing.Point(76, 91)
        Me.lblDriverInfo.Name = "lblDriverInfo"
        Me.lblDriverInfo.Size = New System.Drawing.Size(286, 34)
        Me.lblDriverInfo.TabIndex = 12
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(8, 92)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(59, 13)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Driver Info:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(2, 135)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(76, 13)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Driver Version:"
        '
        'lblInterfaceVersion
        '
        Me.lblInterfaceVersion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblInterfaceVersion.Location = New System.Drawing.Point(232, 134)
        Me.lblInterfaceVersion.Name = "lblInterfaceVersion"
        Me.lblInterfaceVersion.Size = New System.Drawing.Size(42, 17)
        Me.lblInterfaceVersion.TabIndex = 20
        Me.lblInterfaceVersion.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(143, 135)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(90, 13)
        Me.Label6.TabIndex = 19
        Me.Label6.Text = "Interface Version:"
        '
        'lblName
        '
        Me.lblName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblName.Location = New System.Drawing.Point(164, 22)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(121, 17)
        Me.lblName.TabIndex = 22
        Me.lblName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(129, 23)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(38, 13)
        Me.Label4.TabIndex = 21
        Me.Label4.Text = "Name:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(30, 163)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(47, 13)
        Me.Label8.TabIndex = 23
        Me.Label8.Text = "Position:"
        '
        'gbProperties
        '
        Me.gbProperties.Controls.Add(Me.lblSupportedActionsList)
        Me.gbProperties.Controls.Add(Me.lblSupportedActions)
        Me.gbProperties.Controls.Add(Me.Label14)
        Me.gbProperties.Controls.Add(Me.lblPosition)
        Me.gbProperties.Controls.Add(Me.lblDriverVersion)
        Me.gbProperties.Controls.Add(Me.lblDescription)
        Me.gbProperties.Controls.Add(Me.lblName)
        Me.gbProperties.Controls.Add(Me.lblDriverInfo)
        Me.gbProperties.Controls.Add(Me.lblInterfaceVersion)
        Me.gbProperties.Controls.Add(Me.chkConnected)
        Me.gbProperties.Controls.Add(Me.Label8)
        Me.gbProperties.Controls.Add(Me.Label3)
        Me.gbProperties.Controls.Add(Me.Label5)
        Me.gbProperties.Controls.Add(Me.Label4)
        Me.gbProperties.Controls.Add(Me.Label7)
        Me.gbProperties.Controls.Add(Me.Label6)
        Me.gbProperties.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbProperties.Location = New System.Drawing.Point(12, 73)
        Me.gbProperties.Name = "gbProperties"
        Me.gbProperties.Size = New System.Drawing.Size(376, 217)
        Me.gbProperties.TabIndex = 25
        Me.gbProperties.TabStop = False
        Me.gbProperties.Text = " Properties "
        '
        'lblSupportedActionsList
        '
        Me.lblSupportedActionsList.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSupportedActionsList.Location = New System.Drawing.Point(139, 180)
        Me.lblSupportedActionsList.Name = "lblSupportedActionsList"
        Me.lblSupportedActionsList.Size = New System.Drawing.Size(223, 34)
        Me.lblSupportedActionsList.TabIndex = 29
        '
        'lblSupportedActions
        '
        Me.lblSupportedActions.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSupportedActions.Location = New System.Drawing.Point(232, 162)
        Me.lblSupportedActions.Name = "lblSupportedActions"
        Me.lblSupportedActions.Size = New System.Drawing.Size(42, 17)
        Me.lblSupportedActions.TabIndex = 28
        Me.lblSupportedActions.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(136, 163)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(97, 13)
        Me.Label14.TabIndex = 27
        Me.Label14.Text = "Supported Actions:"
        '
        'lblPosition
        '
        Me.lblPosition.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblPosition.Location = New System.Drawing.Point(77, 163)
        Me.lblPosition.Name = "lblPosition"
        Me.lblPosition.Size = New System.Drawing.Size(42, 17)
        Me.lblPosition.TabIndex = 26
        Me.lblPosition.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDriverVersion
        '
        Me.lblDriverVersion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblDriverVersion.Location = New System.Drawing.Point(77, 135)
        Me.lblDriverVersion.Name = "lblDriverVersion"
        Me.lblDriverVersion.Size = New System.Drawing.Size(42, 17)
        Me.lblDriverVersion.TabIndex = 25
        Me.lblDriverVersion.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'gbFilters
        '
        Me.gbFilters.Controls.Add(Me.lblFocusOffset1)
        Me.gbFilters.Controls.Add(Me.lblFilter5Name)
        Me.gbFilters.Controls.Add(Me.lblFilter4Name)
        Me.gbFilters.Controls.Add(Me.lblFilter3Name)
        Me.gbFilters.Controls.Add(Me.lblFilter2Name)
        Me.gbFilters.Controls.Add(Me.lblFilter1Name)
        Me.gbFilters.Controls.Add(Me.lblFocusOffset5)
        Me.gbFilters.Controls.Add(Me.lblFocusOffset4)
        Me.gbFilters.Controls.Add(Me.lblFocusOffset3)
        Me.gbFilters.Controls.Add(Me.lblFocusOffset2)
        Me.gbFilters.Controls.Add(Me.Label9)
        Me.gbFilters.Controls.Add(Me.lblFilter5Color)
        Me.gbFilters.Controls.Add(Me.Label19)
        Me.gbFilters.Controls.Add(Me.lblFilter4Color)
        Me.gbFilters.Controls.Add(Me.Label17)
        Me.gbFilters.Controls.Add(Me.lblFilter3Color)
        Me.gbFilters.Controls.Add(Me.Label15)
        Me.gbFilters.Controls.Add(Me.lblFilter2Color)
        Me.gbFilters.Controls.Add(Me.Label13)
        Me.gbFilters.Controls.Add(Me.Label11)
        Me.gbFilters.Controls.Add(Me.Label10)
        Me.gbFilters.Controls.Add(Me.lblFilter1Color)
        Me.gbFilters.Controls.Add(Me.Label2)
        Me.gbFilters.Location = New System.Drawing.Point(12, 296)
        Me.gbFilters.Name = "gbFilters"
        Me.gbFilters.Size = New System.Drawing.Size(276, 175)
        Me.gbFilters.TabIndex = 26
        Me.gbFilters.TabStop = False
        Me.gbFilters.Text = " Filters "
        '
        'lblFocusOffset1
        '
        Me.lblFocusOffset1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFocusOffset1.Location = New System.Drawing.Point(210, 34)
        Me.lblFocusOffset1.Name = "lblFocusOffset1"
        Me.lblFocusOffset1.Size = New System.Drawing.Size(53, 20)
        Me.lblFocusOffset1.TabIndex = 17
        Me.lblFocusOffset1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblFilter5Name
        '
        Me.lblFilter5Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFilter5Name.Location = New System.Drawing.Point(52, 140)
        Me.lblFilter5Name.Name = "lblFilter5Name"
        Me.lblFilter5Name.Size = New System.Drawing.Size(100, 20)
        Me.lblFilter5Name.TabIndex = 30
        Me.lblFilter5Name.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblFilter4Name
        '
        Me.lblFilter4Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFilter4Name.Location = New System.Drawing.Point(52, 112)
        Me.lblFilter4Name.Name = "lblFilter4Name"
        Me.lblFilter4Name.Size = New System.Drawing.Size(100, 20)
        Me.lblFilter4Name.TabIndex = 29
        Me.lblFilter4Name.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblFilter3Name
        '
        Me.lblFilter3Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFilter3Name.Location = New System.Drawing.Point(52, 86)
        Me.lblFilter3Name.Name = "lblFilter3Name"
        Me.lblFilter3Name.Size = New System.Drawing.Size(100, 20)
        Me.lblFilter3Name.TabIndex = 28
        Me.lblFilter3Name.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblFilter2Name
        '
        Me.lblFilter2Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFilter2Name.Location = New System.Drawing.Point(52, 60)
        Me.lblFilter2Name.Name = "lblFilter2Name"
        Me.lblFilter2Name.Size = New System.Drawing.Size(100, 20)
        Me.lblFilter2Name.TabIndex = 27
        Me.lblFilter2Name.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblFilter1Name
        '
        Me.lblFilter1Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFilter1Name.Location = New System.Drawing.Point(52, 34)
        Me.lblFilter1Name.Name = "lblFilter1Name"
        Me.lblFilter1Name.Size = New System.Drawing.Size(100, 20)
        Me.lblFilter1Name.TabIndex = 23
        Me.lblFilter1Name.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblFocusOffset5
        '
        Me.lblFocusOffset5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFocusOffset5.Location = New System.Drawing.Point(210, 140)
        Me.lblFocusOffset5.Name = "lblFocusOffset5"
        Me.lblFocusOffset5.Size = New System.Drawing.Size(53, 20)
        Me.lblFocusOffset5.TabIndex = 22
        Me.lblFocusOffset5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblFocusOffset4
        '
        Me.lblFocusOffset4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFocusOffset4.Location = New System.Drawing.Point(210, 112)
        Me.lblFocusOffset4.Name = "lblFocusOffset4"
        Me.lblFocusOffset4.Size = New System.Drawing.Size(53, 20)
        Me.lblFocusOffset4.TabIndex = 21
        Me.lblFocusOffset4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblFocusOffset3
        '
        Me.lblFocusOffset3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFocusOffset3.Location = New System.Drawing.Point(210, 86)
        Me.lblFocusOffset3.Name = "lblFocusOffset3"
        Me.lblFocusOffset3.Size = New System.Drawing.Size(53, 20)
        Me.lblFocusOffset3.TabIndex = 20
        Me.lblFocusOffset3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblFocusOffset2
        '
        Me.lblFocusOffset2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFocusOffset2.Location = New System.Drawing.Point(210, 60)
        Me.lblFocusOffset2.Name = "lblFocusOffset2"
        Me.lblFocusOffset2.Size = New System.Drawing.Size(53, 20)
        Me.lblFocusOffset2.TabIndex = 19
        Me.lblFocusOffset2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(203, 18)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(67, 13)
        Me.Label9.TabIndex = 18
        Me.Label9.Text = "Focus Offset"
        '
        'lblFilter5Color
        '
        Me.lblFilter5Color.BackColor = System.Drawing.Color.LavenderBlush
        Me.lblFilter5Color.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFilter5Color.Location = New System.Drawing.Point(168, 140)
        Me.lblFilter5Color.Name = "lblFilter5Color"
        Me.lblFilter5Color.Size = New System.Drawing.Size(20, 20)
        Me.lblFilter5Color.TabIndex = 16
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(4, 143)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(38, 13)
        Me.Label19.TabIndex = 14
        Me.Label19.Text = "Filter 5"
        '
        'lblFilter4Color
        '
        Me.lblFilter4Color.BackColor = System.Drawing.Color.LavenderBlush
        Me.lblFilter4Color.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFilter4Color.Location = New System.Drawing.Point(168, 112)
        Me.lblFilter4Color.Name = "lblFilter4Color"
        Me.lblFilter4Color.Size = New System.Drawing.Size(20, 20)
        Me.lblFilter4Color.TabIndex = 13
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(4, 115)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(38, 13)
        Me.Label17.TabIndex = 11
        Me.Label17.Text = "Filter 4"
        '
        'lblFilter3Color
        '
        Me.lblFilter3Color.BackColor = System.Drawing.Color.LavenderBlush
        Me.lblFilter3Color.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFilter3Color.Location = New System.Drawing.Point(168, 86)
        Me.lblFilter3Color.Name = "lblFilter3Color"
        Me.lblFilter3Color.Size = New System.Drawing.Size(20, 20)
        Me.lblFilter3Color.TabIndex = 10
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(4, 89)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(38, 13)
        Me.Label15.TabIndex = 8
        Me.Label15.Text = "Filter 3"
        '
        'lblFilter2Color
        '
        Me.lblFilter2Color.BackColor = System.Drawing.Color.LavenderBlush
        Me.lblFilter2Color.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFilter2Color.Location = New System.Drawing.Point(168, 60)
        Me.lblFilter2Color.Name = "lblFilter2Color"
        Me.lblFilter2Color.Size = New System.Drawing.Size(20, 20)
        Me.lblFilter2Color.TabIndex = 7
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(4, 63)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(38, 13)
        Me.Label13.TabIndex = 5
        Me.Label13.Text = "Filter 2"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(163, 18)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(31, 13)
        Me.Label11.TabIndex = 4
        Me.Label11.Text = "Color"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(50, 15)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(60, 13)
        Me.Label10.TabIndex = 3
        Me.Label10.Text = "Filter Name"
        '
        'lblFilter1Color
        '
        Me.lblFilter1Color.BackColor = System.Drawing.Color.LavenderBlush
        Me.lblFilter1Color.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFilter1Color.Location = New System.Drawing.Point(168, 34)
        Me.lblFilter1Color.Name = "lblFilter1Color"
        Me.lblFilter1Color.Size = New System.Drawing.Size(20, 20)
        Me.lblFilter1Color.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(4, 37)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Filter 1"
        '
        'pnlNavs
        '
        Me.pnlNavs.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pnlNavs.Controls.Add(Me.lblCurrentFilter)
        Me.pnlNavs.Controls.Add(Me.btnNext)
        Me.pnlNavs.Controls.Add(Me.btnPrev)
        Me.pnlNavs.Location = New System.Drawing.Point(294, 321)
        Me.pnlNavs.Name = "pnlNavs"
        Me.pnlNavs.Size = New System.Drawing.Size(97, 141)
        Me.pnlNavs.TabIndex = 30
        '
        'lblCurrentFilter
        '
        Me.lblCurrentFilter.BackColor = System.Drawing.Color.LavenderBlush
        Me.lblCurrentFilter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCurrentFilter.Location = New System.Drawing.Point(23, 49)
        Me.lblCurrentFilter.Name = "lblCurrentFilter"
        Me.lblCurrentFilter.Size = New System.Drawing.Size(45, 43)
        Me.lblCurrentFilter.TabIndex = 32
        '
        'btnNext
        '
        Me.btnNext.Location = New System.Drawing.Point(11, 105)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(75, 23)
        Me.btnNext.TabIndex = 31
        Me.btnNext.Text = "Next"
        Me.btnNext.UseVisualStyleBackColor = True
        '
        'btnPrev
        '
        Me.btnPrev.Location = New System.Drawing.Point(11, 13)
        Me.btnPrev.Name = "btnPrev"
        Me.btnPrev.Size = New System.Drawing.Size(75, 23)
        Me.btnPrev.TabIndex = 30
        Me.btnPrev.Text = "Previous"
        Me.btnPrev.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(89, 7)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(90, 13)
        Me.Label12.TabIndex = 31
        Me.Label12.Text = "Firmware Version:"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblFirmwareVersion
        '
        Me.lblFirmwareVersion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFirmwareVersion.Location = New System.Drawing.Point(177, 5)
        Me.lblFirmwareVersion.Name = "lblFirmwareVersion"
        Me.lblFirmwareVersion.Size = New System.Drawing.Size(100, 18)
        Me.lblFirmwareVersion.TabIndex = 32
        Me.lblFirmwareVersion.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TestFilterWheelForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(400, 481)
        Me.Controls.Add(Me.lblFirmwareVersion)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.pnlNavs)
        Me.Controls.Add(Me.gbFilters)
        Me.Controls.Add(Me.gbProperties)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.labelDriverId)
        Me.Controls.Add(Me.btnConnect)
        Me.Controls.Add(Me.btnChoose)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "TestFilterWheelForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Test Filter Wheel Driver"
        Me.gbProperties.ResumeLayout(False)
        Me.gbProperties.PerformLayout()
        Me.gbFilters.ResumeLayout(False)
        Me.gbFilters.PerformLayout()
        Me.pnlNavs.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents labelDriverId As System.Windows.Forms.Label
    Private WithEvents btnConnect As System.Windows.Forms.Button
    Private WithEvents btnChoose As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents chkConnected As System.Windows.Forms.CheckBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents lblDescription As System.Windows.Forms.Label
    Friend WithEvents lblDriverInfo As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents lblInterfaceVersion As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents lblName As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents gbProperties As System.Windows.Forms.GroupBox
    Friend WithEvents lblPosition As System.Windows.Forms.Label
    Friend WithEvents lblDriverVersion As System.Windows.Forms.Label
    Friend WithEvents gbFilters As System.Windows.Forms.GroupBox
    Friend WithEvents lblFilter5Color As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents lblFilter4Color As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents lblFilter3Color As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents lblFilter2Color As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents lblFilter1Color As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lblFocusOffset5 As System.Windows.Forms.Label
    Friend WithEvents lblFocusOffset4 As System.Windows.Forms.Label
    Friend WithEvents lblFocusOffset3 As System.Windows.Forms.Label
    Friend WithEvents lblFocusOffset2 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents lblFocusOffset1 As System.Windows.Forms.Label
    Friend WithEvents lblFilter5Name As System.Windows.Forms.Label
    Friend WithEvents lblFilter4Name As System.Windows.Forms.Label
    Friend WithEvents lblFilter3Name As System.Windows.Forms.Label
    Friend WithEvents lblFilter2Name As System.Windows.Forms.Label
    Friend WithEvents lblFilter1Name As System.Windows.Forms.Label
    Friend WithEvents pnlNavs As System.Windows.Forms.Panel
    Friend WithEvents lblCurrentFilter As System.Windows.Forms.Label
    Friend WithEvents btnNext As System.Windows.Forms.Button
    Friend WithEvents btnPrev As System.Windows.Forms.Button
    Friend WithEvents lblSupportedActions As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents lblSupportedActionsList As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents lblFirmwareVersion As System.Windows.Forms.Label

End Class
