﻿Public Class DriversTest

    Private Sub btnFocuser_Click(sender As System.Object, e As System.EventArgs) Handles btnFocuser.Click
        TestFocuserForm.Show()
    End Sub

    Private Sub btnFilterWheel_Click(sender As System.Object, e As System.EventArgs) Handles btnFilterWheel.Click
        TestFilterWheelForm.Show()
    End Sub

End Class