﻿Imports ASCOM

Public Class TestFilterWheelForm

    Private Const MAX_FILTERS As Integer = 5
    Private Const FILTERWHEEL_MOVING As Integer = -1

    Private Driver As DriverAccess.FilterWheel
    Private Utils As New Utilities.Util
    Private lblFilterName(MAX_FILTERS - 1) As Label
    Private lblFilterColor(MAX_FILTERS - 1) As Label
    Private lblFocusOffset(MAX_FILTERS - 1) As Label
    Private FilterSlots As Integer = 0

    ''' <summary>
    ''' This event is where the driver is choosen. The device ID will be saved in the settings.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub btnChoose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnChoose.Click
        Dim progId As String

        progId = DriverAccess.FilterWheel.Choose(My.Settings.FilterWheelDriverId)
        If Not String.IsNullOrEmpty(progId) Then
            My.Settings.FilterWheelDriverId = progId
        End If
        SetUIState()
    End Sub

    ''' <summary>
    ''' Connects to the device to be tested.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub btnConnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConnect.Click
        If (IsConnected) Then
            Driver.Connected = False
        Else
            Application.UseWaitCursor = True
            Me.Cursor = Cursors.WaitCursor
            Driver = New DriverAccess.FilterWheel(My.Settings.FilterWheelDriverId)
            Try
                Driver.Connected = True
                GetProperties()
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Connect ASCOM Driver")
            End Try
        End If
        SetUIState()
        Me.Cursor = Cursors.Default
        Application.UseWaitCursor = False
    End Sub

    Private Sub TestFilterWheelForm_Activated(sender As Object, e As System.EventArgs) Handles Me.Activated
        InitControlsArrays()
        SetUIState()
    End Sub

    Private Sub TestFilterWheelForm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        InitControlsArrays()
        SetUIState()
    End Sub

    Private Sub TestFilterWheelForm_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        If IsConnected Then
            Driver.Connected = False
        End If
        If Driver IsNot Nothing Then
            Driver.Dispose()
        End If

        ' the settings are saved automatically when this application is closed.
    End Sub
    ' Set up arrays of controls.
    Private Sub InitControlsArrays()
        If lblFilterName(0) Is Nothing Then
            lblFilterName(0) = lblFilter1Name
            lblFilterName(1) = lblFilter2Name
            lblFilterName(2) = lblFilter3Name
            lblFilterName(3) = lblFilter4Name
            lblFilterName(4) = lblFilter5Name

            lblFilterColor(0) = lblFilter1Color
            lblFilterColor(1) = lblFilter2Color
            lblFilterColor(2) = lblFilter3Color
            lblFilterColor(3) = lblFilter4Color
            lblFilterColor(4) = lblFilter5Color

            lblFocusOffset(0) = lblFocusOffset1
            lblFocusOffset(1) = lblFocusOffset2
            lblFocusOffset(2) = lblFocusOffset3
            lblFocusOffset(3) = lblFocusOffset4
            lblFocusOffset(4) = lblFocusOffset5
        End If
    End Sub

    ''' <summary>
    ''' Sets the state of the UI depending on the device state
    ''' </summary>
    Private Sub SetUIState()
        chkConnected.Checked = IsConnected
        btnConnect.Enabled = Not String.IsNullOrEmpty(My.Settings.FilterWheelDriverId)
        btnChoose.Enabled = Not IsConnected
        btnConnect.Text = CStr(IIf(IsConnected, "Disconnect", "Connect"))
        gbProperties.Enabled = IsConnected
        gbFilters.Enabled = IsConnected
        pnlNavs.Enabled = IsConnected
    End Sub


    ''' <summary>
    ''' Gets a value indicating whether this instance is connected.
    ''' </summary>
    ''' <returns>
    ''' <c>true</c> if this instance is connected; otherwise, <c>false</c>.
    ''' </returns>
    ''' <remarks></remarks>
    Private ReadOnly Property IsConnected() As Boolean
        Get
            If Driver IsNot Nothing Then
                Return Driver.Connected
            End If

            Return False
        End Get
    End Property

    ''' <summary>
    ''' Retrieve Filter Wheel properties from the ASCOM driver.
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetProperties()
        chkConnected.Checked = Driver.Connected
        lblDescription.Text = Driver.Description
        lblDriverInfo.Text = Driver.DriverInfo
        lblDriverVersion.Text = Driver.DriverVersion
        lblInterfaceVersion.Text = Driver.InterfaceVersion.ToString
        lblName.Text = Driver.Name
        lblPosition.Text = Driver.Position.ToString
        lblSupportedActions.Text = Driver.SupportedActions.Count.ToString
        lblFirmwareVersion.Text = String.Empty
        lblSupportedActionsList.Text = String.Empty
        For Each item As String In Driver.SupportedActions
            lblSupportedActionsList.Text &= item & vbCrLf
            If item.Contains("FirmwareVersion") Then
                lblFirmwareVersion.Text = Driver.Action(item, "")
            ElseIf item.Contains("HomeWheel") Then
                Driver.Action(item, "")
                Do
                    Utils.WaitForMilliseconds(100)
                Loop While Driver.Position = FILTERWHEEL_MOVING       ' wait for filter wheel move to complete
            Else
                Driver.Action(item, "")
            End If
        Next
        lblPosition.Text = Driver.Position.ToString     ' in case moved due to an Action

        Dim filterNames() As String = Driver.Names
        Dim focusOffsets() As Integer = Driver.FocusOffsets

        FilterSlots = filterNames.Length
        For ndx As Integer = 0 To FilterSlots - 1
            If ndx > MAX_FILTERS - 1 Then
                Exit For
            End If
            If filterNames.Length > ndx Then
                lblFilterName(ndx).Text = filterNames(ndx)
                lblFilterColor(ndx).BackColor = Color.FromName(filterNames(ndx))
                lblFocusOffset(ndx).Text = focusOffsets(ndx).ToString
            End If
        Next
        lblCurrentFilter.BackColor = lblFilterColor(Driver.Position).BackColor()

    End Sub

    ''' <summary>
    ''' Select previous Filter Wheel position.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnPrev_Click(sender As System.Object, e As System.EventArgs) Handles btnPrev.Click
        SetPrevPosition()
    End Sub

    ''' <summary>
    ''' Select next Filter Wheel position.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnNext_Click(sender As System.Object, e As System.EventArgs) Handles btnNext.Click
        SetNextPosition()
    End Sub

    ''' <summary>
    ''' Set previous Filter Wheel position.
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetPrevPosition()
        Dim curr_position As Short = Driver.Position
        Dim new_position As Short

        If curr_position > 0 Then
            new_position = curr_position - CShort(1)
        Else    ' do wrap-around
            new_position = CShort(Math.Min(FilterSlots - 1, MAX_FILTERS - CShort(1)))   ' last position
        End If
        SetFilterWheelPosition(new_position)
    End Sub

    ''' <summary>
    ''' Set next Filter Wheel position.
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetNextPosition()
        Dim curr_position As Short = Driver.Position
        Dim new_position As Short

        If (curr_position < FilterSlots - 1) AndAlso (curr_position < MAX_FILTERS - 1) Then
            new_position = curr_position + CShort(1)
        Else    ' do wrap-around
            new_position = 0                    ' first position
        End If
        SetFilterWheelPosition(new_position)
    End Sub

    ''' <summary>
    ''' Position Filter Wheel.
    ''' </summary>
    ''' <param name="position">Filter Wheel position to move to</param>
    ''' <remarks></remarks>
    Private Sub SetFilterWheelPosition(position As Short)
        Application.UseWaitCursor = True
        Me.Cursor = Cursors.WaitCursor
        lblCurrentFilter.BackColor = Color.Silver
        Driver.Position = position
        Do
            Utils.WaitForMilliseconds(100)
        Loop While Driver.Position = FILTERWHEEL_MOVING       ' wait for filter wheel move to complete
        lblPosition.Text = position.ToString
        lblCurrentFilter.BackColor = lblFilterColor(position).BackColor()
        Me.Cursor = Cursors.Default
        Application.UseWaitCursor = False
    End Sub

End Class
