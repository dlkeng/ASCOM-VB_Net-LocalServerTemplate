﻿Imports ASCOM

Public Class TestFocuserForm

    Private Driver As ASCOM.DriverAccess.Focuser
    Private Utils As New Utilities.Util
    Private SupportedActions As ArrayList

    ''' <summary>
    ''' This event is where the driver is choosen. The device ID will be saved in the settings.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub btnChoose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnChoose.Click
        Dim progId As String

        progId = DriverAccess.Focuser.Choose(My.Settings.FocuserDriverId)
        If Not String.IsNullOrEmpty(progId) Then
            My.Settings.FocuserDriverId = progId
        End If
        SetUIState()
    End Sub

    ''' <summary>
    ''' Connects to the device to be tested.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub btnConnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConnect.Click
        If (IsConnected) Then
            Driver.Connected = False
        Else
            Application.UseWaitCursor = True
            Me.Cursor = Cursors.WaitCursor
            Driver = New ASCOM.DriverAccess.Focuser(My.Settings.FocuserDriverId)
            Try
                Driver.Connected = True
                GetProperties()
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Connect ASCOM Driver")
            End Try
        End If
        SetUIState()
        Me.Cursor = Cursors.Default
        Application.UseWaitCursor = False
    End Sub

    Private Sub TestFocuserForm_Activated(sender As Object, e As System.EventArgs) Handles Me.Activated
        SetUIState()
    End Sub

    Private Sub TestFocuserForm_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        SetUIState()
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        If IsConnected Then
            Driver.Connected = False
        End If
        If Driver IsNot Nothing Then
            Driver.Dispose()
        End If

        ' the settings are saved automatically when this application is closed.
    End Sub

    ''' <summary>
    ''' Sets the state of the UI depending on the device state
    ''' </summary>
    Private Sub SetUIState()
        chkConnected.Checked = IsConnected
        btnConnect.Enabled = Not String.IsNullOrEmpty(My.Settings.FocuserDriverId)
        btnChoose.Enabled = Not IsConnected
        btnConnect.Text = CStr(IIf(IsConnected, "Disconnect", "Connect"))
        gbProperties.Enabled = IsConnected
        pnlNavs.Enabled = IsConnected
    End Sub

    ''' <summary>
    ''' Gets a value indicating whether this instance is connected.
    ''' </summary>
    ''' <value>
    ''' 
    ''' <c>true</c> if this instance is connected; otherwise, <c>false</c>.
    ''' 
    ''' </value>
    Private ReadOnly Property IsConnected() As Boolean
        Get
            If Driver IsNot Nothing Then
                Return Driver.Connected
            End If

            Return False
        End Get
    End Property

    ''' <summary>
    ''' Retrieve Focuser properties from the ASCOM driver.
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetProperties()
        chkConnected.Checked = Driver.Connected
        lblDescription.Text = Driver.Description
        lblDriverInfo.Text = Driver.DriverInfo
        lblDriverVersion.Text = Driver.DriverVersion
        lblInterfaceVersion.Text = Driver.InterfaceVersion.ToString
        lblName.Text = Driver.Name
        SupportedActions = Driver.SupportedActions
        lblSupportedActions.Text = SupportedActions.Count.ToString
        lblFirmwareVersion.Text = String.Empty
        lblSupportedActionsList.Text = String.Empty
        For Each item As String In SupportedActions
            lblSupportedActionsList.Text &= item & vbCrLf
            If item.Contains("FirmwareVersion") Then
                lblFirmwareVersion.Text = Driver.Action(item, "")
            ElseIf item.Contains("HomeFocuser") Then
                Driver.Action(item, "")
                Do
                    Utils.WaitForMilliseconds(100)
                Loop While Driver.IsMoving       ' wait for focuser move to complete
            ElseIf item.Contains("SetRate") Then
                Driver.Action(item, "2")
            ElseIf item.Contains("SetMode") Then
                Driver.Action(item, "1")
            ElseIf item.Contains("QueryHome") Then
                chkIsHome.Checked = CBool(Driver.Action(item, ""))
            Else
                'Driver.Action(item, "")
            End If
        Next
        chkAbsolute.Checked = Driver.Absolute
        chkIsMoving.Checked = Driver.IsMoving
        lblMaxIncrement.Text = Driver.MaxIncrement.ToString
        lblMaxStep.Text = Driver.MaxStep.ToString
        chkTempComp.Checked = Driver.TempComp
        chkTempCompAvailable.Checked = Driver.TempCompAvailable
        lblTemperature.Text = RetrieveTemperature()
    End Sub

    ''' <summary>
    ''' Move Focuser to specified offset.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnMoveFocus_Click(sender As System.Object, e As System.EventArgs) Handles btnMoveFocus.Click
        Application.UseWaitCursor = True
        Me.Cursor = Cursors.WaitCursor
        Driver.Move(CInt(nudOffsetValue.Value))
        Do
            Utils.WaitForMilliseconds(100)
        Loop While Driver.IsMoving       ' wait for focuser move to complete
        For Each item As String In SupportedActions
            If item.Contains("QueryHome") Then
                chkIsHome.Checked = CBool(Driver.Action(item, ""))
                Exit For
            End If
        Next
        Me.Cursor = Cursors.Default
        Application.UseWaitCursor = False
    End Sub

    ''' <summary>
    ''' Home Focuser.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnHomeFocus_Click(sender As System.Object, e As System.EventArgs) Handles btnHomeFocus.Click
        Application.UseWaitCursor = True
        Me.Cursor = Cursors.WaitCursor
        For Each item As String In SupportedActions
            If item.Contains("HomeFocuser") Then
                Driver.Action(item, "")
                Do
                    Utils.WaitForMilliseconds(100)
                Loop While Driver.IsMoving       ' wait for focuser move to complete
                Exit For
            End If
        Next
        For Each item As String In SupportedActions
            If item.Contains("QueryHome") Then
                chkIsHome.Checked = CBool(Driver.Action(item, ""))
                Exit For
            End If
        Next
        Me.Cursor = Cursors.Default
        Application.UseWaitCursor = False
    End Sub

    ''' <summary>
    ''' Retrieve temperature from Focuser on demand.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub lblTemperature_DoubleClick(sender As Object, e As System.EventArgs) Handles lblTemperature.DoubleClick
        Application.UseWaitCursor = True
        Me.Cursor = Cursors.WaitCursor
        lblTemperature.Text = RetrieveTemperature()
        Me.Cursor = Cursors.Default
        Application.UseWaitCursor = False
    End Sub

    ''' <summary>
    ''' Retrieve temperature (in °F) from Focuser.
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function RetrieveTemperature() As String
        Return (((Driver.Temperature * 9) / 5) + 32).ToString   ' to °F
    End Function

End Class
