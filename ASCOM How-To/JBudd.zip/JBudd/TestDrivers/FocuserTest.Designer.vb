﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TestFocuserForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblDriverId = New System.Windows.Forms.Label()
        Me.btnConnect = New System.Windows.Forms.Button()
        Me.btnChoose = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblFirmwareVersion = New System.Windows.Forms.Label()
        Me.gbProperties = New System.Windows.Forms.GroupBox()
        Me.lblTemperature = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.chkTempCompAvailable = New System.Windows.Forms.CheckBox()
        Me.chkTempComp = New System.Windows.Forms.CheckBox()
        Me.lblMaxStep = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.lblMaxIncrement = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.chkIsMoving = New System.Windows.Forms.CheckBox()
        Me.chkAbsolute = New System.Windows.Forms.CheckBox()
        Me.lblSupportedActionsList = New System.Windows.Forms.Label()
        Me.lblSupportedActions = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.lblDriverVersion = New System.Windows.Forms.Label()
        Me.lblDescription = New System.Windows.Forms.Label()
        Me.lblName = New System.Windows.Forms.Label()
        Me.lblDriverInfo = New System.Windows.Forms.Label()
        Me.lblInterfaceVersion = New System.Windows.Forms.Label()
        Me.chkConnected = New System.Windows.Forms.CheckBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.nudOffsetValue = New System.Windows.Forms.NumericUpDown()
        Me.btnMoveFocus = New System.Windows.Forms.Button()
        Me.btnHomeFocus = New System.Windows.Forms.Button()
        Me.chkIsHome = New System.Windows.Forms.CheckBox()
        Me.pnlNavs = New System.Windows.Forms.Panel()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.gbProperties.SuspendLayout()
        CType(Me.nudOffsetValue, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlNavs.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblDriverId
        '
        Me.lblDriverId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblDriverId.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.ASCOM.JBudd.My.MySettings.Default, "FocuserDriverId", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.lblDriverId.Location = New System.Drawing.Point(12, 37)
        Me.lblDriverId.Name = "lblDriverId"
        Me.lblDriverId.Size = New System.Drawing.Size(291, 21)
        Me.lblDriverId.TabIndex = 5
        Me.lblDriverId.Text = Global.ASCOM.JBudd.My.MySettings.Default.FocuserDriverId
        Me.lblDriverId.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnConnect
        '
        Me.btnConnect.Location = New System.Drawing.Point(316, 36)
        Me.btnConnect.Name = "btnConnect"
        Me.btnConnect.Size = New System.Drawing.Size(72, 23)
        Me.btnConnect.TabIndex = 4
        Me.btnConnect.Text = "Connect"
        Me.btnConnect.UseVisualStyleBackColor = True
        '
        'btnChoose
        '
        Me.btnChoose.Location = New System.Drawing.Point(316, 7)
        Me.btnChoose.Name = "btnChoose"
        Me.btnChoose.Size = New System.Drawing.Size(72, 23)
        Me.btnChoose.TabIndex = 3
        Me.btnChoose.Text = "Choose"
        Me.btnChoose.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(10, 21)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(50, 13)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Driver Id:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(89, 7)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(90, 13)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Firmware Version:"
        '
        'lblFirmwareVersion
        '
        Me.lblFirmwareVersion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFirmwareVersion.Location = New System.Drawing.Point(177, 5)
        Me.lblFirmwareVersion.Name = "lblFirmwareVersion"
        Me.lblFirmwareVersion.Size = New System.Drawing.Size(100, 18)
        Me.lblFirmwareVersion.TabIndex = 8
        Me.lblFirmwareVersion.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'gbProperties
        '
        Me.gbProperties.Controls.Add(Me.lblTemperature)
        Me.gbProperties.Controls.Add(Me.Label8)
        Me.gbProperties.Controls.Add(Me.Label11)
        Me.gbProperties.Controls.Add(Me.chkTempCompAvailable)
        Me.gbProperties.Controls.Add(Me.chkTempComp)
        Me.gbProperties.Controls.Add(Me.lblMaxStep)
        Me.gbProperties.Controls.Add(Me.Label10)
        Me.gbProperties.Controls.Add(Me.lblMaxIncrement)
        Me.gbProperties.Controls.Add(Me.Label9)
        Me.gbProperties.Controls.Add(Me.chkIsMoving)
        Me.gbProperties.Controls.Add(Me.chkAbsolute)
        Me.gbProperties.Controls.Add(Me.lblSupportedActionsList)
        Me.gbProperties.Controls.Add(Me.lblSupportedActions)
        Me.gbProperties.Controls.Add(Me.Label14)
        Me.gbProperties.Controls.Add(Me.lblDriverVersion)
        Me.gbProperties.Controls.Add(Me.lblDescription)
        Me.gbProperties.Controls.Add(Me.lblName)
        Me.gbProperties.Controls.Add(Me.lblDriverInfo)
        Me.gbProperties.Controls.Add(Me.lblInterfaceVersion)
        Me.gbProperties.Controls.Add(Me.chkConnected)
        Me.gbProperties.Controls.Add(Me.Label3)
        Me.gbProperties.Controls.Add(Me.Label5)
        Me.gbProperties.Controls.Add(Me.Label4)
        Me.gbProperties.Controls.Add(Me.Label7)
        Me.gbProperties.Controls.Add(Me.Label6)
        Me.gbProperties.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbProperties.Location = New System.Drawing.Point(12, 73)
        Me.gbProperties.Name = "gbProperties"
        Me.gbProperties.Size = New System.Drawing.Size(376, 320)
        Me.gbProperties.TabIndex = 26
        Me.gbProperties.TabStop = False
        Me.gbProperties.Text = " Properties "
        '
        'lblTemperature
        '
        Me.lblTemperature.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTemperature.Location = New System.Drawing.Point(270, 272)
        Me.lblTemperature.Name = "lblTemperature"
        Me.lblTemperature.Size = New System.Drawing.Size(36, 17)
        Me.lblTemperature.TabIndex = 39
        Me.lblTemperature.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(305, 274)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(17, 13)
        Me.Label8.TabIndex = 40
        Me.Label8.Text = "°F"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(201, 274)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(70, 13)
        Me.Label11.TabIndex = 38
        Me.Label11.Text = "Temperature:"
        '
        'chkTempCompAvailable
        '
        Me.chkTempCompAvailable.AutoCheck = False
        Me.chkTempCompAvailable.AutoSize = True
        Me.chkTempCompAvailable.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkTempCompAvailable.Location = New System.Drawing.Point(29, 296)
        Me.chkTempCompAvailable.Name = "chkTempCompAvailable"
        Me.chkTempCompAvailable.Size = New System.Drawing.Size(132, 17)
        Me.chkTempCompAvailable.TabIndex = 37
        Me.chkTempCompAvailable.Text = "Temp Comp Available:"
        Me.chkTempCompAvailable.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkTempCompAvailable.UseVisualStyleBackColor = True
        '
        'chkTempComp
        '
        Me.chkTempComp.AutoCheck = False
        Me.chkTempComp.AutoSize = True
        Me.chkTempComp.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkTempComp.Location = New System.Drawing.Point(75, 273)
        Me.chkTempComp.Name = "chkTempComp"
        Me.chkTempComp.Size = New System.Drawing.Size(86, 17)
        Me.chkTempComp.TabIndex = 36
        Me.chkTempComp.Text = "Temp Comp:"
        Me.chkTempComp.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkTempComp.UseVisualStyleBackColor = True
        '
        'lblMaxStep
        '
        Me.lblMaxStep.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblMaxStep.Location = New System.Drawing.Point(80, 243)
        Me.lblMaxStep.Name = "lblMaxStep"
        Me.lblMaxStep.Size = New System.Drawing.Size(42, 17)
        Me.lblMaxStep.TabIndex = 35
        Me.lblMaxStep.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(26, 244)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(55, 13)
        Me.Label10.TabIndex = 34
        Me.Label10.Text = "Max Step:"
        '
        'lblMaxIncrement
        '
        Me.lblMaxIncrement.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblMaxIncrement.Location = New System.Drawing.Point(79, 217)
        Me.lblMaxIncrement.Name = "lblMaxIncrement"
        Me.lblMaxIncrement.Size = New System.Drawing.Size(42, 17)
        Me.lblMaxIncrement.TabIndex = 33
        Me.lblMaxIncrement.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(2, 218)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(80, 13)
        Me.Label9.TabIndex = 32
        Me.Label9.Text = "Max Increment:"
        '
        'chkIsMoving
        '
        Me.chkIsMoving.AutoCheck = False
        Me.chkIsMoving.AutoSize = True
        Me.chkIsMoving.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkIsMoving.Location = New System.Drawing.Point(6, 186)
        Me.chkIsMoving.Name = "chkIsMoving"
        Me.chkIsMoving.Size = New System.Drawing.Size(75, 17)
        Me.chkIsMoving.TabIndex = 31
        Me.chkIsMoving.Text = "Is Moving:"
        Me.chkIsMoving.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkIsMoving.UseVisualStyleBackColor = True
        '
        'chkAbsolute
        '
        Me.chkAbsolute.AutoCheck = False
        Me.chkAbsolute.AutoSize = True
        Me.chkAbsolute.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkAbsolute.Location = New System.Drawing.Point(11, 163)
        Me.chkAbsolute.Name = "chkAbsolute"
        Me.chkAbsolute.Size = New System.Drawing.Size(70, 17)
        Me.chkAbsolute.TabIndex = 30
        Me.chkAbsolute.Text = "Absolute:"
        Me.chkAbsolute.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkAbsolute.UseVisualStyleBackColor = True
        '
        'lblSupportedActionsList
        '
        Me.lblSupportedActionsList.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSupportedActionsList.Location = New System.Drawing.Point(139, 183)
        Me.lblSupportedActionsList.Name = "lblSupportedActionsList"
        Me.lblSupportedActionsList.Size = New System.Drawing.Size(223, 73)
        Me.lblSupportedActionsList.TabIndex = 29
        '
        'lblSupportedActions
        '
        Me.lblSupportedActions.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSupportedActions.Location = New System.Drawing.Point(232, 162)
        Me.lblSupportedActions.Name = "lblSupportedActions"
        Me.lblSupportedActions.Size = New System.Drawing.Size(42, 17)
        Me.lblSupportedActions.TabIndex = 28
        Me.lblSupportedActions.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(136, 163)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(97, 13)
        Me.Label14.TabIndex = 27
        Me.Label14.Text = "Supported Actions:"
        '
        'lblDriverVersion
        '
        Me.lblDriverVersion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblDriverVersion.Location = New System.Drawing.Point(77, 135)
        Me.lblDriverVersion.Name = "lblDriverVersion"
        Me.lblDriverVersion.Size = New System.Drawing.Size(42, 17)
        Me.lblDriverVersion.TabIndex = 25
        Me.lblDriverVersion.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDescription
        '
        Me.lblDescription.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblDescription.Location = New System.Drawing.Point(77, 47)
        Me.lblDescription.Name = "lblDescription"
        Me.lblDescription.Size = New System.Drawing.Size(285, 34)
        Me.lblDescription.TabIndex = 10
        '
        'lblName
        '
        Me.lblName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblName.Location = New System.Drawing.Point(164, 22)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(121, 17)
        Me.lblName.TabIndex = 22
        Me.lblName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDriverInfo
        '
        Me.lblDriverInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblDriverInfo.Location = New System.Drawing.Point(76, 91)
        Me.lblDriverInfo.Name = "lblDriverInfo"
        Me.lblDriverInfo.Size = New System.Drawing.Size(286, 34)
        Me.lblDriverInfo.TabIndex = 12
        '
        'lblInterfaceVersion
        '
        Me.lblInterfaceVersion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblInterfaceVersion.Location = New System.Drawing.Point(232, 134)
        Me.lblInterfaceVersion.Name = "lblInterfaceVersion"
        Me.lblInterfaceVersion.Size = New System.Drawing.Size(42, 17)
        Me.lblInterfaceVersion.TabIndex = 20
        Me.lblInterfaceVersion.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'chkConnected
        '
        Me.chkConnected.AutoCheck = False
        Me.chkConnected.AutoSize = True
        Me.chkConnected.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkConnected.Location = New System.Drawing.Point(11, 22)
        Me.chkConnected.Name = "chkConnected"
        Me.chkConnected.Size = New System.Drawing.Size(81, 17)
        Me.chkConnected.TabIndex = 7
        Me.chkConnected.Text = "Connected:"
        Me.chkConnected.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkConnected.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(8, 46)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(63, 13)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Description:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(8, 92)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(59, 13)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Driver Info:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(129, 23)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(38, 13)
        Me.Label4.TabIndex = 21
        Me.Label4.Text = "Name:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(2, 135)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(76, 13)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Driver Version:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(143, 135)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(90, 13)
        Me.Label6.TabIndex = 19
        Me.Label6.Text = "Interface Version:"
        '
        'nudOffsetValue
        '
        Me.nudOffsetValue.Location = New System.Drawing.Point(283, 32)
        Me.nudOffsetValue.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.nudOffsetValue.Minimum = New Decimal(New Integer() {1000, 0, 0, -2147483648})
        Me.nudOffsetValue.Name = "nudOffsetValue"
        Me.nudOffsetValue.Size = New System.Drawing.Size(49, 20)
        Me.nudOffsetValue.TabIndex = 27
        Me.nudOffsetValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnMoveFocus
        '
        Me.btnMoveFocus.Location = New System.Drawing.Point(199, 28)
        Me.btnMoveFocus.Name = "btnMoveFocus"
        Me.btnMoveFocus.Size = New System.Drawing.Size(75, 28)
        Me.btnMoveFocus.TabIndex = 28
        Me.btnMoveFocus.Text = "Move Focus"
        Me.btnMoveFocus.UseVisualStyleBackColor = True
        '
        'btnHomeFocus
        '
        Me.btnHomeFocus.Location = New System.Drawing.Point(25, 26)
        Me.btnHomeFocus.Name = "btnHomeFocus"
        Me.btnHomeFocus.Size = New System.Drawing.Size(75, 28)
        Me.btnHomeFocus.TabIndex = 29
        Me.btnHomeFocus.Text = "Home Focus"
        Me.btnHomeFocus.UseVisualStyleBackColor = True
        '
        'chkIsHome
        '
        Me.chkIsHome.AutoCheck = False
        Me.chkIsHome.AutoSize = True
        Me.chkIsHome.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkIsHome.Location = New System.Drawing.Point(27, 9)
        Me.chkIsHome.Name = "chkIsHome"
        Me.chkIsHome.Size = New System.Drawing.Size(68, 17)
        Me.chkIsHome.TabIndex = 32
        Me.chkIsHome.Text = "Is Home:"
        Me.chkIsHome.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkIsHome.UseVisualStyleBackColor = True
        '
        'pnlNavs
        '
        Me.pnlNavs.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pnlNavs.Controls.Add(Me.Label12)
        Me.pnlNavs.Controls.Add(Me.btnHomeFocus)
        Me.pnlNavs.Controls.Add(Me.chkIsHome)
        Me.pnlNavs.Controls.Add(Me.nudOffsetValue)
        Me.pnlNavs.Controls.Add(Me.btnMoveFocus)
        Me.pnlNavs.Location = New System.Drawing.Point(23, 399)
        Me.pnlNavs.Name = "pnlNavs"
        Me.pnlNavs.Size = New System.Drawing.Size(359, 70)
        Me.pnlNavs.TabIndex = 33
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(288, 13)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(35, 13)
        Me.Label12.TabIndex = 33
        Me.Label12.Text = "Offset"
        '
        'TestFocuserForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(400, 481)
        Me.Controls.Add(Me.pnlNavs)
        Me.Controls.Add(Me.gbProperties)
        Me.Controls.Add(Me.lblFirmwareVersion)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblDriverId)
        Me.Controls.Add(Me.btnConnect)
        Me.Controls.Add(Me.btnChoose)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "TestFocuserForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Test Focuser Driver"
        Me.gbProperties.ResumeLayout(False)
        Me.gbProperties.PerformLayout()
        CType(Me.nudOffsetValue, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlNavs.ResumeLayout(False)
        Me.pnlNavs.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents lblDriverId As System.Windows.Forms.Label
    Private WithEvents btnConnect As System.Windows.Forms.Button
    Private WithEvents btnChoose As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lblFirmwareVersion As System.Windows.Forms.Label
    Friend WithEvents gbProperties As System.Windows.Forms.GroupBox
    Friend WithEvents lblSupportedActionsList As System.Windows.Forms.Label
    Friend WithEvents lblSupportedActions As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents lblDriverVersion As System.Windows.Forms.Label
    Friend WithEvents lblDescription As System.Windows.Forms.Label
    Friend WithEvents lblName As System.Windows.Forms.Label
    Friend WithEvents lblDriverInfo As System.Windows.Forms.Label
    Friend WithEvents lblInterfaceVersion As System.Windows.Forms.Label
    Friend WithEvents chkConnected As System.Windows.Forms.CheckBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents chkAbsolute As System.Windows.Forms.CheckBox
    Friend WithEvents chkIsMoving As System.Windows.Forms.CheckBox
    Friend WithEvents lblMaxIncrement As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents lblMaxStep As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents chkTempComp As System.Windows.Forms.CheckBox
    Friend WithEvents chkTempCompAvailable As System.Windows.Forms.CheckBox
    Friend WithEvents lblTemperature As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents nudOffsetValue As System.Windows.Forms.NumericUpDown
    Friend WithEvents btnMoveFocus As System.Windows.Forms.Button
    Friend WithEvents btnHomeFocus As System.Windows.Forms.Button
    Friend WithEvents chkIsHome As System.Windows.Forms.CheckBox
    Friend WithEvents pnlNavs As System.Windows.Forms.Panel
    Friend WithEvents Label12 As System.Windows.Forms.Label

End Class
