This folder contains the example VB skeleton solution for the VB ASCOM LocalServer
prior to the LocalServer modifications.

