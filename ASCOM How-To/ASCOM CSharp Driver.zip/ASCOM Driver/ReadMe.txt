This folder contains the example C# skeleton solution for a C# ASCOM driver.

