This folder contains the images for the Visual Basic ASCOM LocalServer modifications process.

