This folder contains the example Visual Basic skeleton projects for the Visual Basic ASCOM LocalServer.
 - PreLocalServer Skeleton  = Visual Basic ASCOM LocalServer skeleton solution prior to LocalServer modifications
 - LocalServer Skeleton     = Visual Basic ASCOM LocalServer skeleton solution

