This folder contains Inno Setup info for an ASCOM driver.

