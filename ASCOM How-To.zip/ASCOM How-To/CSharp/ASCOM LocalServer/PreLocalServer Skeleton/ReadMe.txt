This folder contains the example C# skeleton solution for the C# ASCOM LocalServer
prior to the LocalServer modifications.

