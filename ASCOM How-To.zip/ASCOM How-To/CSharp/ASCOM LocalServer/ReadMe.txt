This folder contains the example C# skeleton projects for the C# ASCOM LocalServer.
 - PreLocalServer Skeleton  = C# ASCOM LocalServer skeleton solution prior to LocalServer modifications
 - LocalServer Skeleton     = C# ASCOM LocalServer skeleton solution

