This folder contains the images for the Visual C# ASCOM LocalServer modifications process.

